import React, { useState, useRef, useEffect, useCallback, useMemo, memo } from "react";
import ReactMarkdown from "react-markdown";
import rehypeRaw from "rehype-raw";
import "./ChatInterface.css";

const ChatInterface = memo(({
 messages,
 onSendMessage,
 selectedBot,
 selectedDocument,
 onMessageDelete,
 isMessageSending,
 isLoadingSession = false,  
 activeSessionId  
}) => {
 // Removed excessive console.log in production code
 
 const [messageInput, setMessageInput] = useState("");
 const [selectedFile, setSelectedFile] = useState(null);
 const [localMessages, setLocalMessages] = useState([]);
 const [isWaitingForServerMessages, setIsWaitingForServerMessages] = useState(false);

 const messagesEndRef = useRef(null);
 const textareaRef = useRef(null);

 const scrollToBottom = useCallback(() => {
   messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
 }, []);

 // Handle textarea height adjustment
 useEffect(() => {
   if (textareaRef.current) {
     textareaRef.current.style.height = "auto";
     textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 150)}px`;
   }
 }, [messageInput]);

 // Scroll to bottom when messages change
 useEffect(() => {
   scrollToBottom();
 }, [localMessages, scrollToBottom]);

 // Consolidated message update logic
 useEffect(() => {
   if (!messages) return;
   
   if (isWaitingForServerMessages && messages.length === 0) {
     // Server temporarily returned 0 messages, keeping local messages
     return;
   }

   if (messages.length > 0) {
     // Received messages from server
     setIsWaitingForServerMessages(false);
     setLocalMessages(messages);
   } else if (!isWaitingForServerMessages) {
     // Clear messages when parent sends empty array and not waiting
     setLocalMessages([]);
   }
 }, [messages, isWaitingForServerMessages]);

 // Handle bot type changes
 useEffect(() => {
   setLocalMessages([]);
   setIsWaitingForServerMessages(false);
 }, [selectedBot]);

 // Handle document selection changes
 useEffect(() => {
   if (selectedBot === 'document' && !selectedDocument) {
     setLocalMessages([]);
     setIsWaitingForServerMessages(false);
   }
 }, [selectedBot, selectedDocument]);

 const handleSubmit = useCallback((e) => {
   e.preventDefault();

   if ((messageInput.trim() || selectedFile) && !isMessageSending) {
     const timestamp = Date.now();

     const newUserMessage = {
       id: `temp_${timestamp}`,
       content: messageInput,
       sender: "user",
       timestamp: new Date(),
       isLocal: true,
     };

     setIsWaitingForServerMessages(true);
     setLocalMessages(prev => [...prev, newUserMessage]);

     onSendMessage(messageInput, selectedFile);

     setMessageInput("");
     setSelectedFile(null);

     if (textareaRef.current) {
       textareaRef.current.style.height = "auto";
     }
   }
 }, [messageInput, selectedFile, isMessageSending, onSendMessage]);

 // Handle Enter key for submission
 const handleKeyDown = useCallback((e) => {
   if (e.key === 'Enter' && !e.shiftKey) {
     e.preventDefault();
     handleSubmit(e);
   }
 }, [handleSubmit]);

 const handleFileSelect = useCallback((e) => {
   if (e.target.files.length > 0) {
     setSelectedFile(e.target.files[0]);
     if (textareaRef.current) {
       textareaRef.current.focus();
     }
   }
 }, []);

 const handleRemoveFile = useCallback(() => {
   setSelectedFile(null);
   if (textareaRef.current) {
     textareaRef.current.focus();
   }
 }, []);

 const formatTime = (timestamp) => {
   if (!timestamp) return "";
   try {
     return new Date(timestamp).toLocaleTimeString("en-US", {
       hour: "2-digit",
       minute: "2-digit",
     });
   } catch (e) {
     console.error("Error formatting timestamp:", e);
     return "";
   }
 };

 const handleMessageDelete = useCallback((messageId) => {
   if (onMessageDelete && window.confirm("Delete this message?")) {
     if (messageId.startsWith('temp_')) {
       setLocalMessages(prev => prev.filter(m => m.id !== messageId));
       return;
     }
     const originalId = messageId.split('_')[0];
     setLocalMessages(prev => prev.filter(m => m.id !== messageId));
     onMessageDelete(originalId);
   }
 }, [onMessageDelete]);

 const getPlaceholderText = useMemo(() => {
   if (isMessageSending) return "Processing...";
   if (selectedFile) return "Add a message (optional)...";
   switch (selectedBot) {
     case "grammar": return "Enter text to check grammar...";
     case "email": return "Type your email content...";
     case "document":
       return selectedDocument ? `Ask a question about ${selectedDocument.name}...` : "First upload or select a document...";
     case "meeting_insights": return "Ask about meeting insights...";
     default: return "Type a message...";
   }
 }, [isMessageSending, selectedFile, selectedBot, selectedDocument]);

 const getBotTitle = useMemo(() => {
   switch (selectedBot) {
     case "grammar": return "Grammar Correction Bot";
     case "email": return "Email Assistant Bot";
     case "document": return selectedDocument ? `Document: ${selectedDocument.name}` : "Document Chat Bot";
     case "meeting_insights": return "Meeting Insights";
     default: return "Chatbot Assistant";
   }
 }, [selectedBot, selectedDocument]);

 const getWelcomeMessage = useMemo(() => {
   switch (selectedBot) {
     case "grammar": return "I can help you correct grammar and improve your writing. Type some text to get started!";
     case "email": return "I can help you draft professional emails. Let me know what you need!";
     case "document":
       return selectedDocument ? `You're chatting about \"${selectedDocument.name}\". Ask any questions about this document!` : "Upload a document and ask me questions about it. I'll help you understand and analyze the content.";
     case "meeting_insights": return "I can provide insights from your meetings. Ask me about key points, summaries, or decisions!";
     default: return "How can I assist you today?";
   }
 }, [selectedBot, selectedDocument]);

  const detectContentType = useCallback((content) => {
    if (!content) return 'text';
      const hasHtmlTags = /<(?!\/?(em|strong|b|i|u|s|code|pre|blockquote)\b)[a-z][\s\S]*?>/i.test(content);
      const hasHeadings = /^#{1,6}\s+.+$/m.test(content);
      const hasBoldItalic = /(\*\*\*|\*\*|__|\*|_)(.+?)(\*\*\*|\*\*|__|\*|_)/i.test(content);
      const hasLists = /^(\s*[-*+]\s|\s*\d+\.\s)/m.test(content);
      const hasBlockquote = /^>\s+.+$/m.test(content);
      const hasCodeBlock = /```[\s\S]*?```/.test(content);
      if (hasHtmlTags) return 'html';
      if (hasHeadings || hasBoldItalic || hasLists || hasBlockquote || hasCodeBlock) {
        return 'markdown';
      }    
    return 'text';
  }, []);


  const preprocessContent = useCallback((content) => {
    if (!content) return '';
    const contentType = detectContentType(content);
    
    if (contentType === 'html') {
      let processed = content;
      processed = processed.replace(/<div\s*>\s*<\/div>/g, '');
      processed = processed.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
      processed = processed.replace(/\*(.*?)\*/g, '<em>$1</em>');
      processed = processed.replace(/(\.)(\s+-\s+)/g, '$1<br>$2');
      processed = processed.replace(/([.?!])\s*(Corrections Made|Suggestions|Disclaimer):/g, '$1<br><strong>$2:</strong>');
      return processed;
    } else if (contentType === 'markdown') {
      let processed = content;
      processed = processed.replace(/\n{3,}/g, '\n\n');
      processed = processed.replace(/\n{2,}(#{1,6})\s/g, '\n$1 ');
      processed = processed.replace(/\n{2,}(\s*[-*+])\s/g, '\n$1 ');
      processed = processed.replace(/\n{2,}(\s*\d+\.)\s/g, '\n$1 ');
      processed = processed.replace(/(\*\*[^*:]+)\*\*\s*:/g, '$1:**');
      processed = processed.replace(/(\*\*[^*:]+:\*\*)\n+/g, '$1 ');
      processed = processed.replace(/([.?!])\s*(Corrections Made|Suggestions|Disclaimer):/g, '$1\n\n**$2:**');
      return processed;
    } else {
      return content;
    }
  }, [detectContentType]);

  const renderContent = useCallback((content) => {
    if (!content) return null;
    
    try {
      const contentType = detectContentType(content);
      const processedContent = preprocessContent(content);
      
      if (contentType === 'html') {
        return <div className="html-content" dangerouslySetInnerHTML={{ __html: processedContent }} />;
      } else {
        return (
          <ReactMarkdown rehypePlugins={[rehypeRaw]}>
            {processedContent}
          </ReactMarkdown>
        );
      }
    } catch (error) {
      console.error("Error rendering content:", error);
      return <div className="plain-text-fallback">{content}</div>;
    }
  }, [detectContentType, preprocessContent]);

  const displayMessages = useMemo(() => {
    return [...localMessages];
  }, [localMessages]);

 const MessageComponent = useCallback(({ message, index }) => {
   return (
     <div key={message.id || index} className={`message ${message.sender} ${message.isLocal ? 'local-message' : ''}`}>
       <div className="message-content">
         {message.isLoading ? (
           <div className="typing-indicator">
             <span></span>
             <span></span>
             <span></span>
           </div>
         ) : (
           message.sender === 'bot' ? renderContent(message.content) : message.content
         )}
       </div>
       <div className="message-footer">
         <span className="message-timestamp">{formatTime(message.timestamp)}</span>
         {message.sender === 'user' && onMessageDelete && (
           <button
             className="message-delete-btn"
             onClick={() => handleMessageDelete(message.id)}
             title="Delete this message"
           >
             <i className="fas fa-trash-alt"></i>
           </button>
         )}
       </div>
     </div>
   );
 }, [formatTime, handleMessageDelete, onMessageDelete, renderContent]);

 // Optimized render logic for messages
 const renderMessages = useMemo(() => {
   if (displayMessages.length === 0) {
     return (
       <div className="chat-welcome">
         <h3>Welcome to {getBotTitle}</h3>
         <p>{getWelcomeMessage}</p>
       </div>
     );
   }

   return displayMessages.map((message, index) => (
     <MessageComponent key={message.id || index} message={message} index={index} />
   ));
 }, [displayMessages, getBotTitle, getWelcomeMessage, MessageComponent]);

 return (
   <div className="chat-interface">
     <div className="chat-header">
       <h2>{getBotTitle}</h2>
       {selectedBot === 'document' && selectedDocument && (
         <div className="chat-subtitle">Chat history is specific to this document</div>
       )}
     </div>

     <div className="chat-messages">
       {isLoadingSession && (
         <div className="session-loading-indicator">
           <span>Loading conversation...</span>
         </div>
       )}
       {!isLoadingSession && renderMessages}
       <div ref={messagesEndRef} />
     </div>

     <div className="chat-input-container">
       <form onSubmit={handleSubmit} className="chat-input-form">
         <div className="input-area">
           {selectedFile && (
             <div className="inline-file-preview">
               <i className="fas fa-file"></i>
               <span className="file-name">{selectedFile.name}</span>
               <button type="button" className="remove-file-btn" onClick={handleRemoveFile}>
                 <i className="fas fa-times"></i>
               </button>
             </div>
           )}

           <textarea
             ref={textareaRef}
             value={messageInput}
             onChange={(e) => setMessageInput(e.target.value)}
             onKeyDown={handleKeyDown}
             placeholder={getPlaceholderText}
             className="chat-input"
             disabled={(selectedBot === "document" && !selectedDocument) || isMessageSending}
             rows="1"
           />

           <label htmlFor="file-upload" className={`file-upload-btn ${isMessageSending ? 'disabled' : ''}`}>
             <i className="fas fa-paperclip"></i>
             <input
               id="file-upload"
               type="file"
               accept=".pdf,.doc,.docx,.txt"
               onChange={handleFileSelect}
               style={{ display: "none" }}
               disabled={isMessageSending}
             />
           </label>

           <button
             type="submit"
             className={`chat-input-send ${isMessageSending ? 'sending' : ''}`}
             disabled={(selectedBot === "document" && !selectedDocument) || (!messageInput.trim() && !selectedFile) || isMessageSending}
           >
             {isMessageSending ? (
               <span className="loading-spinner"></span>
             ) : (
               <span className="send-icon"></span>
             )}
           </button>
         </div>
       </form>
     </div>
   </div>
 );
});

export default ChatInterface;

