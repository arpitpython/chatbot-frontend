
const getBaseUrl = () => {
  const hostname = window.location.hostname;
  const port = window.location.port;

  if (hostname === 'localhost' || hostname === '127.0.0.1' || 
      port === '3000' || port === '8080' || port === '5173') {
    return 'http://127.0.0.1:8000';
  } else {
    return 'https://chatflowapp-api-dev.aixsol.com'; 
  }
};

export const checkAndAuthenticateFromSession = () => {
  const userId = sessionStorage.getItem('user_id');
  const loginKey = sessionStorage.getItem('login_key');
  
  if (userId && loginKey) {
    return { authenticated: true, userId, loginKey };
  }
  
  return { authenticated: false };
};

export { getBaseUrl }; 
export const MAIN_ENDPOINT = getBaseUrl();
export const AUTOMATION_LOGIN = "https://automation.analytix.com/login";

