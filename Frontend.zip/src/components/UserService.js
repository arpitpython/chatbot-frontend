import axios from "axios";
import { MAIN_ENDPOINT } from "../components/endpoints";

export const getUserDetails = async (userId, loginKey, AUTOMATION_LOGIN) => {
  console.log("UserService: getUserDetails called with params:", { userId, loginKey });
  
  if (!userId || !loginKey) {
    userId = sessionStorage.getItem("user_id");
    loginKey = sessionStorage.getItem("login_key");
    console.log("UserService: Retrieved credentials from sessionStorage:", { userId, loginKey });
    
    if (!userId || !loginKey) {
      console.log("UserService: No credentials available, authentication failed");
      return { success: false, error: "Missing user ID or login key. Please log in again." };
    }
  }
  
  try {
    console.log("UserService: Making authentication request");
    
    const response = await axios.get(
      `${MAIN_ENDPOINT}/api/authenticate-user-token/`,
      {
        params: { user_id: userId, login_key: loginKey },
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json"
        }
      }
    );
    
    console.log("UserService: Authentication response status:", response.status);
    
    if (response.data.status === 'success') {
      const { login_user, user_data } = response.data;
      
      console.log("UserService: Authentication successful, storing user data");
      
      sessionStorage.setItem("user_id", user_data.user || userId);
      sessionStorage.setItem("login_key", loginKey);
      sessionStorage.setItem("main_login_key", loginKey);
      sessionStorage.setItem("email", user_data.email);
      sessionStorage.setItem("session_time_out", user_data.session_time_out);
      sessionStorage.setItem("user_name", user_data?.first_name);
      
      return { success: true, userData: user_data, is_authenticated: true };
    } else {
      console.log("UserService: Authentication failed");
      return { success: false, error: "Authentication failed. Invalid credentials." };
    }
  } catch (error) {
    console.error("UserService: Authentication error:", error);
    
    const errorMessage = error.response?.status === 401 
      ? "Invalid credentials. Please log in again."
      : error.response?.data?.error ?? "Failed to authenticate. Please try again later.";
    
    return { 
      success: false, 
      error: errorMessage
    };
  }
};

export const checkAdminStatus = async () => {
  console.log("UserService: Checking admin status");
  const email = sessionStorage.getItem("email");
  
  if (!email) {
    console.log("UserService: No email found in session storage, cannot check admin status");
    return false; 
  }

  try {
    console.log("UserService: Making admin check request for email:", email);
    const response = await axios.post(`${MAIN_ENDPOINT}/api/check-user-role/`, {
      email,
    });
    
    console.log("UserService: Admin check response:", response.data);
    return response.data.success ? true : false;
  } catch (error) {
    console.error("UserService: Admin check error:", error);
    return false; 
  }
};