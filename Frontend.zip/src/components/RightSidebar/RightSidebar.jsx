import React, { useState, useEffect } from "react";
import "./RightSidebar.css";


function TextFileViewer({ url }) {
  const [text, setText] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    fetch(url)
      .then((res) => {
        if (!res.ok) {
          throw new Error("Failed to fetch text file");
        }
        return res.text();
      })
      .then(setText)
      .catch((err) => setError(err.message));
  }, [url]);

  if (error) {
    return <div className="text-red-500">Error: {error}</div>;
  }

  return (
    <div className="p-4 bg-gray-100 rounded-lg max-h-[500px] overflow-auto">
      <pre className="whitespace-pre-wrap text-sm">{text}</pre>
    </div>
  );
}


const RightSidebar = ({ selectedDocument }) => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [previewContent, setPreviewContent] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (selectedDocument) {
      loadDocumentPreview(selectedDocument);
    } else {
      setPreviewContent(null);
    }
  }, [selectedDocument]);
  
  const loadDocumentPreview = (document) => {
    setIsLoading(true);

    if (!document) {
      setIsLoading(false);
      setPreviewContent(null);
      return;
    }

    const { type, url, name } = document;
    const extension = name ? name.split(".").pop().toLowerCase() : "";
    const fileType = type ? type.toString() : "";
    
    setTimeout(() => {
      setIsLoading(false);

      if (fileType.includes("pdf") || extension === "pdf") {
        setPreviewContent({ type: "pdf", url });
      } else if (
        fileType.includes("word") ||
        extension === "doc" ||
        extension === "docx"
      ) {
        setPreviewContent({ type: "doc", url });
      } else if (
        fileType.includes("text") ||
        extension === "txt"
      ) {
        setPreviewContent({ type: "text", url });
      } else {
        setPreviewContent({ type: "unknown", url });
      }
    }, 500);
  };

  const headerText = isCollapsed
    ? "Document Viewer"
    : selectedDocument
    ? selectedDocument.name
    : "Document Viewer";

  return (
    <div className={`right-sidebar ${isCollapsed ? "collapsed" : ""}`}>
      <div className="document-viewer-header">
        <div className="header-title-area">
          <button
            className="collapse-btn"
            onClick={() => setIsCollapsed(!isCollapsed)}
            title={isCollapsed ? "Expand" : "Collapse"}
          >
            <span
              className={`collapse-icon ${isCollapsed ? "is-collapsed" : ""}`}
            ></span>
          </button>
          <h3>{headerText}</h3>
        </div>

        {!isCollapsed && selectedDocument && (
          <button
            className="download-button"
            onClick={() => window.open(selectedDocument.url, "_blank")}
          >
            Download
          </button>
        )}
      </div>

      {!isCollapsed && (
        <div className="document-viewer-content">
          {isLoading ? (
            <div className="document-loading">
              <div className="loading-spinner"></div>
              <p>Loading document preview...</p>
            </div>
          ) : !selectedDocument ? (
            <div className="empty-document-message">
              <div className="empty-doc-icon"></div>
              <p>No document selected</p>
              <p className="empty-doc-subtitle">
                Please select a document from the left sidebar.
              </p>
            </div>
          ) : (
            renderDocumentContent(previewContent, selectedDocument)
          )}
        </div>
      )}
    </div>
  );
};

const renderDocumentContent = (previewContent, document) => {
  if (!previewContent) return null;

  const { type, url } = previewContent;
  const { name } = document;

  switch (type) {
    case "pdf":
      return (
        <div className="pdf-document-preview">
          <embed
            src={url}
            title={name}
            width="100%"
            height="100%"
            type="application/pdf"
            className="pdf-iframe"
          />
        </div>
      );

    case "doc":
      return (
        <div className="doc-document-preview">
          <iframe
            src={url}
            title={name}
            width="100%"
            height="100%"
            className="doc-iframe"
          />
        </div>
      );
      
    case "text":
      return (
        <div className="text-document-preview">
          <iframe
            src={url}
            title={name}
            width="100%"
            height="100%"
            style={{ minHeight: "500px" }}
            className="text-iframe"
          />
        </div>
      );

    default:
      return (
        <div className="unknown-document-preview">
          <div className="file-icon-large"></div>
          <h3>{name}</h3>
          <p className="preview-message">
            Preview not available for this file type.
          </p>
          <button
            className="download-button"
            onClick={() => window.open(url, "_blank")}
          >
            Download File
          </button>
        </div>
      );
  }
};

export default RightSidebar;
