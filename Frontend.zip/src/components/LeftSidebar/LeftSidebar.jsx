import "@fortawesome/fontawesome-free/css/all.min.css";
import React, { useState, useEffect, memo } from "react";
import { useNavigate } from "react-router-dom";
import "./LeftSidebar.css";

const LeftSidebar = memo(({
 selectedBot,
 onBotChange,
 documents,
 onDocumentSelect,
 onDocumentUpload,
 onDocumentDelete,
 chatSessions,
 selectedDocumentId,
 isDocumentsLoading,
 activeSessionId,
 onSessionSelect,
 onNewChat,
 onSessionDelete,
 isNewChat,
 pendingNewSessionId
}) => {
 console.log("LeftSidebar render", { 
   selectedBot, 
   documentsCount: documents?.length || 0, 
   selectedDocumentId,
   activeSessionId,
   isNewChat,
   pendingNewSessionId
 });

 const [isCollapsed, setIsCollapsed] = useState(false);
 const navigate = useNavigate();
 
 useEffect(() => {
   console.log("LeftSidebar documents effect", { 
     selectedBot, 
     documentsCount: documents?.length || 0, 
     selectedDocumentId 
   });
   
   if (selectedBot === 'document' && documents.length > 0 && 
       (!selectedDocumentId || !documents.find(doc => doc.id === selectedDocumentId))) {
     console.log("Selecting first document by default", documents[0]);
     onDocumentSelect(documents[0]);
   }
 }, [selectedBot, documents]);

 const handleBotChange = (e) => {
   const newBotType = e.target.value;
   console.log("Bot type changed", { from: selectedBot, to: newBotType });
   onBotChange(newBotType);
 };

 const handleFileSelect = (e) => {
   console.log("File selected", e.target.files);
   const file = e.target.files[0];
   if (file) {
     console.log("Processing file for upload", { name: file.name, size: file.size });
     const newDocument = {
       id: Date.now(),
       name: file.name,
       type: file.type || getFileTypeFromExtension(file.name),
       size: file.size,
       lastModified: file.lastModified,
       url: URL.createObjectURL(file),
       file: file
     };
     console.log("Created document object", newDocument);
     onDocumentUpload(newDocument);
   }
 };

 const handleDocumentSelect = (doc) => {
   console.log("Document selected", doc);
   if (doc.id !== selectedDocumentId) {
     console.log("Changing selected document", { from: selectedDocumentId, to: doc.id });
     onDocumentSelect(doc);
   } else {
     console.log("Document already selected, no change");
   }
 };

 const handleDeleteDocument = (e, documentId) => {
   console.log("Delete document clicked", { documentId });
   e.stopPropagation();
   if (window.confirm("Are you sure you want to delete this document? This will also delete all associated chat messages.")) {
     console.log("Confirmed document deletion", { documentId });
     onDocumentDelete(documentId);
   } else {
     console.log("Document deletion cancelled");
   }
 };

 const handleSessionSelect = (sessionId) => {
   console.log("Session selected", { sessionId, previousSessionId: activeSessionId });
   onSessionSelect(sessionId);
 };
 
 const handleSessionDelete = (e, sessionId) => {
   console.log("Delete session clicked", { sessionId });
   e.stopPropagation();
   if (onSessionDelete && window.confirm("Are you sure you want to delete this conversation?")) {
     console.log("Confirmed session deletion", { sessionId });
     onSessionDelete(sessionId);
   } else {
     console.log("Session deletion cancelled");
   }
 };
 
 const handleClearDocumentConversation = () => {
   console.log("Clear document conversation clicked", { documentId: selectedDocumentId });
   if (window.confirm("Are you sure you want to clear the conversation for this document?")) {
     console.log("Confirmed clearing conversation");
     onNewChat();
   } else {
     console.log("Clearing conversation cancelled");
   }
 };

 const handleNewChat = () => {
   console.log("New chat clicked");
   onNewChat();
 };

 const renderSessionPreviews = () => {
   console.log("Rendering session previews", { 
     selectedBot, 
     sessionsCount: chatSessions[selectedBot]?.length || 0 
   });
   
   if (selectedBot === 'document') {
     console.log("Document mode - not showing sessions");
     return null;
   }
   
   const sessions = chatSessions[selectedBot] || [];
   console.log("Sessions to render", { count: sessions.length });

   return (
     <>
       <div 
         className={`new-chat-button ${isNewChat ? 'active' : ''}`}
         onClick={handleNewChat}
       >
         <i className="fas fa-plus-circle"></i>
         <span>New Chat</span>
       </div>
       
       {sessions.length === 0 ? (
         <div className="empty-sessions">
           <p>No previous conversations.</p>
         </div>
       ) : (
         <div className="session-list">
           {sessions.map((session) => {
             const isActiveSession = session.id === activeSessionId || 
                                    (pendingNewSessionId && session.id === pendingNewSessionId);
             
             console.log(`Session item ${session.id}`, { 
               isActive: isActiveSession, 
               title: session.title || "Untitled" 
             });
               
             return (
               <div 
                 key={session.id} 
                 className={`session-item ${isActiveSession ? 'active' : ''}`}
                 onClick={() => handleSessionSelect(session.id)}
               >
                 <div className="session-preview">
                   <i className="fas fa-comment"></i>
                   <div className="session-text">
                     <div className="session-title">
                       {session.title || "Untitled Conversation"}
                     </div>
                     <div className="session-excerpt">
                       {session.preview || "No preview available"}
                     </div>
                   </div>
                 </div>
                 <div className="session-time">{formatDate(session.created_at)}</div>
                 <button
                   className="session-delete-btn"
                   onClick={(e) => handleSessionDelete(e, session.id)}
                   title="Delete conversation"
                 >
                   <i className="fas fa-trash-alt"></i>
                 </button>
               </div>
             );
           })}
         </div>
       )}
     </>
   );
 };

 const formatDate = (date) => {
   try {
     return new Date(date).toLocaleDateString("en-US", {
       month: "short",
       day: "numeric",
       hour: "2-digit",
       minute: "2-digit",
     });
   } catch (e) {
     console.error("Error formatting date:", e, { date });
     return "Invalid date";
   }
 };

 const getFileTypeFromExtension = (filename) => {
   const extension = filename.split(".").pop().toLowerCase();
   console.log("Getting file type from extension", { filename, extension });

   switch (extension) {
     case "pdf":
       return "application/pdf";
     case "doc":
     case "docx":
       return "application/msword";
     case "xls":
     case "xlsx":
       return "application/vnd.ms-excel";
     case "csv":
       return "text/csv";
     case "txt":
       return "text/plain";
     case "jpg":
     case "jpeg":
       return "image/jpeg";
     case "png":
       return "image/png";
     default:
       return "application/octet-stream";
   }
 };

 const getFileIcon = (fileType, fileName) => {
   const extension = fileName ? fileName.split(".").pop().toLowerCase() : "";
   const fileTypeStr = fileType ? fileType.toString() : "";
   console.log("Getting file icon", { fileType, fileName, extension });

   if (fileTypeStr.includes("pdf") || extension === "pdf") {
     return <i className="fas fa-file-pdf file-icon"></i>;
   } else if (
     fileTypeStr.includes("word") ||
     extension === "doc" ||
     extension === "docx"
   ) {
     return <i className="fas fa-file-word file-icon"></i>;
   } else if (
     fileTypeStr.includes("excel") ||
     extension === "xls" ||
     extension === "xlsx" ||
     extension === "csv"
   ) {
     return <i className="fas fa-file-excel file-icon"></i>;
   } else if (fileTypeStr.includes("image")) {
     return <i className="fas fa-file-image file-icon"></i>;
   } else {
     return <i className="fas fa-file file-icon"></i>;
   }
 };

 const headerText =
   selectedBot === "document" ? "Documents" : "Conversation History";

 console.log("LeftSidebar rendering complete", { 
   isCollapsed, 
   headerText, 
   showingDocuments: selectedBot === "document" 
 });

 return (
   <div className={`left-sidebar ${isCollapsed ? "collapsed" : ""}`}>
     <div className="sidebar-header">
       <h3>{isCollapsed ? "" : headerText}</h3>
       <button
         className="collapse-btn"
         onClick={() => {
           console.log("Toggling sidebar collapse", { current: isCollapsed, new: !isCollapsed });
           setIsCollapsed(!isCollapsed);
         }}
         title={isCollapsed ? "Expand" : "Collapse"}
       >
         <span
           className={`collapse-icon ${isCollapsed ? "is-collapsed" : ""}`}
         ></span>
       </button>
     </div>

     {!isCollapsed && (
       <>
         {selectedBot === "document" ? (
           <div className="document-section">
             <label htmlFor="document-upload" className="document-upload">
               <div className="upload-content">
                 <div className="upload-icon">
                   <i className="fas fa-cloud-upload-alt"></i>
                 </div>
                 <div>Upload Document</div>
                 <div className="file-size-limit">Maximum: 10 MB or 300 Pages</div>
                 <div className="file-allowed">Document Types: PDF, DOC, DOCX, TXT</div>
                 {/* <div className="file-processing-time">Processing Time: 10 seconds per page</div> */}

               </div>
               <input
                 id="document-upload"
                 type="file"
                 accept=".pdf,.doc,.docx,.txt"
                 onChange={handleFileSelect}
                 style={{ display: "none" }}
               />
             </label>

             {selectedDocumentId && (
               <div 
                 className={`new-chat-button ${isNewChat ? 'active' : ''}`}
                 onClick={handleClearDocumentConversation}
               >
                 <i className="fas fa-broom"></i>
                 <span>Clear Conversation</span>
               </div>
             )}

             <div className="document-list-container">
               <h4>Uploaded Documents</h4>
               <div className="document-list">
                 {isDocumentsLoading ? (
                   <div className="document-loading">
                     <div className="loading-spinner"></div>
                     <p>Loading documents...</p>
                   </div>
                 ) : documents.length > 0 ? (
                   documents.map((doc) => {
                     console.log(`Document item ${doc.id}`, { 
                       name: doc.name, 
                       isActive: doc.id === selectedDocumentId 
                     });
                     
                     return (
                       <div
                         key={doc.id}
                         className={`document-card ${doc.id === selectedDocumentId ? "active" : ""}`}
                         onClick={() => handleDocumentSelect(doc)}
                       >
                         <div className="document-card-content">
                           {getFileIcon(doc.type, doc.name)}
                           <div className="document-info">
                             <div className="document-name">{doc.name}</div>
                             <div className="document-meta">
                               {doc.created_at ? formatDate(doc.created_at) : ""}
                             </div>
                           </div>
                         </div>
                         <button
                           className="document-delete-btn"
                           onClick={(e) => handleDeleteDocument(e, doc.id)}
                           title="Delete document"
                         >
                           <i className="fas fa-trash"></i>
                         </button>
                       </div>
                     );
                   })
                 ) : (
                   <div className="empty-documents">
                     No documents uploaded yet.
                   </div>
                 )}
               </div>
             </div>
           </div>
         ) : (
           <div className="session-history">{renderSessionPreviews()}</div>
         )}

         <div className="bot-selector">
           <label htmlFor="bot-select">Select Chatbot:</label>
           <select
             id="bot-select"
             value={selectedBot}
             onChange={handleBotChange}
           >
             <option value="grammar">Grammar Bot</option>
             <option value="email">Email Bot</option>
             <option value="meeting_insights">Meeting Insights</option>
             <option value="document">Document Bot</option>
           </select>
         </div>
       </>
     )}
   </div>
 );
});

export default LeftSidebar;