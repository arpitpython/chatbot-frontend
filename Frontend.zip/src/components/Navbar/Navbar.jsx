import React from "react";
import { AUTOMATION_LOGIN } from "../endpoints";
import "./Navbar.css";

const Navbar = ({ onBackToLanding }) => {
  const handleLogout = () => {
    // Clear any session storage items
    sessionStorage.clear();
    // Redirect to the automation login URL
    window.location.href = AUTOMATION_LOGIN;
  };

  return (
    <nav className="navbar">
      <div className="navbar-container">
        <div className="navbar-brand">
          <img 
            src="/images/analytix-solutions-logo.png" 
            alt="Analytix Solutions Logo" 
            className="logo" 
          />
          <span className="brand-text">Analytix AI Assistant</span>
        </div>
        
        <div className="navbar-actions">
          <button 
            className="back-to-landing-btn"
            onClick={onBackToLanding}
            title="Back to Services"
          >
            <i className="fas fa-home"></i>
            <span>All Services</span>
          </button>
          
          <button 
            className="logout-btn"
            onClick={handleLogout}
            title="Logout"
          >
            <i className="fas fa-power-off"></i>
            <span>Logout</span>
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;