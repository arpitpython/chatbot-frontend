import React, { useEffect, useState, useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Navbar, Nav, Button, Badge } from "react-bootstrap";
import { BsChatSquareDots } from "react-icons/bs";
import { FaDownload, FaRocket, FaWrench, FaCheck, FaEnvelope, FaComments, FaFileAlt } from "react-icons/fa";
import { downloadUserGuide } from "../../utils/api";
import styles from "./LandingPage.module.css";
import { AUTOMATION_LOGIN } from "../endpoints";
import { getUserDetails as UserDetails } from "../UserService";

const StyleIsolator = ({ children }) => {
  return <div className={styles.LandingPage}>{children}</div>;
};

const LandingPage = () => {
  console.log("LandingPage: Component rendering");
  const navigate = useNavigate();
  const location = useLocation();
  const authAttempted = useRef(false);

  const queryParams = new URLSearchParams(location.search);
  const userId = queryParams.get("user_id");
  const loginKey = queryParams.get("login_key");
  
  console.log("LandingPage: URL parameters detected:", Boolean(userId) && Boolean(loginKey));

  const [error, setError] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const botTypeMap = {
    "Grammar Check": "grammar",
    "Email Writing": "email",
    "Meeting Insights": "meeting_insights",
    "Document Analysis": "document"
  };

  const bots = [
    {
      id: 1,
      title: "Grammar Check",
      description: "Elevate your writing skills with AI-powered grammar Review & Correction",
      icon: <FaCheck className={styles.iconCustom} />,
      key: "Grammar Check"
    },
    {
      id: 2,
      title: "Email Writing",
      description: "Compose & review professional emails with ease and efficiency",
      icon: <FaEnvelope className={styles.iconCustom} />,
      key: "Email Writing"
    },
    {
      id: 3,
      title: "Meeting Insights",
      description: "Effortlessly transform meeting discussions into concise, crystal-clear, and actionable insights & minutes",
      icon: <FaComments className={styles.iconCustom} />,
      key: "Meeting Insights"
    },
    {
      id: 4,
      title: "Document Analysis",
      description: "Powerful AI-driven document analysis tools for extracting insights and making informed decisions",
      icon: <FaFileAlt className={styles.iconCustom} />,
      key: "Document Analysis"
    }
  ];

  useEffect(() => {
    const authenticate = async () => {
      if (authAttempted.current || isAuthenticating) {
        return;
      }
      
      setIsAuthenticating(true);
      authAttempted.current = true;
      
      try {
        if (userId && loginKey) {
          console.log("LandingPage: Authenticating with URL parameters");
          const result = await UserDetails(userId, loginKey, AUTOMATION_LOGIN);
          
          if (result.success) {
            console.log("LandingPage: Authentication successful");
            setIsAuthenticated(true);
            
            const cleanUrl = window.location.pathname;
            window.history.replaceState({}, '', cleanUrl);
          } else {
            console.log("LandingPage: Authentication failed:", result.error);
            setError(result.error);
            setTimeout(() => {
              window.location.href = `${AUTOMATION_LOGIN}`;
            }, 3000);
          }
        } else {
          const storedUserId = sessionStorage.getItem('user_id');
          const storedLoginKey = sessionStorage.getItem('login_key');
          
          if (storedUserId && storedLoginKey) {
            console.log("LandingPage: Authenticating with stored credentials");
            const result = await UserDetails(storedUserId, storedLoginKey, AUTOMATION_LOGIN);
            
            if (result.success) {
              console.log("LandingPage: Authentication with stored credentials successful");
              setIsAuthenticated(true);
            } else {
              console.log("LandingPage: Authentication with stored credentials failed");
              setError("Your session has expired. Redirecting to login...");
              setTimeout(() => {
                window.location.href = `${AUTOMATION_LOGIN}`;
              }, 3000);
            }
          } else {
            console.log("LandingPage: No credentials found");
            setError("Authentication required");
            setTimeout(() => {
              window.location.href = `${AUTOMATION_LOGIN}`;
            }, 1500);
          }
        }
      } catch (error) {
        console.error("LandingPage: Authentication error:", error);
        setError(error.message || "Authentication failed");
      } finally {
        setIsAuthenticating(false);
      }
    };
    
    authenticate();
  }, [userId, loginKey]);

  const handleCostModule = async () => {
    navigate("/cost-module");
  };

  const handleGetStarted = (botKey) => {
    console.log("LandingPage: Get Started clicked for bot:", botKey);
    
    const botType = botTypeMap[botKey];
    if (!botType) {
      console.log("LandingPage: Invalid bot type");
      return;
    }
    
    sessionStorage.setItem('bot_type', botType);
    console.log(`LandingPage: Navigating to /chat/${botType}`);
    navigate(`/chat/${botType}`);
  };

  const handleDownload = async () => {
    try {
      await downloadUserGuide();
      setError("");
    } catch (err) {
      setError("Downloading File Error: " + err.message);
    }
  };

  const ErrorModal = ({ error, onClose }) => {
    return (
      <div className={styles['error-modal']}>
        <div className={styles['error-modal-content']}>
          <h3>Error</h3>
          <p>{error}</p>
          <Button onClick={onClose}>Close</Button>
        </div>
      </div>
    );
  };

  return (
    <StyleIsolator>
      <div className={styles['content-wrapper']}>
        <Navbar expand="lg" className={styles['navbar-custom']}>
          <Navbar.Brand href="#home" className={styles['navbar-brand-custom']}>
            <img src="/images/business-transformation-logo.png" alt="Logo" height="50" />
          </Navbar.Brand>
          <Nav className={`ms-auto ${styles['navbar-nav-custom']}`} hidden>
            {isAdmin && (
              <Button
                className="d-flex align-items-center"
                onClick={handleCostModule}
              >
                <FaWrench size={20} className="me-2" />
                Cost Module
              </Button>
            )}
          </Nav>
        </Navbar>

        <section className={styles['hero-section']}>
          <h1 className="display-4 fw-bold mb-4">
            Transform Your Business with AI
          </h1>
          <p className={`lead mb-4 ${styles['hero-lead']}`}>
            Experience the power of AI-driven solutions for smarter business
            decisions
          </p>
          <div className={styles['hero-buttons-container']}>
            <button
              className={`${styles['hero-button1']} ${styles.button}`}
              style={{
                "--clr": "linear-gradient(135deg,rgb(142, 94, 201), #275fa6)",
              }}
              type="button"
              onClick={() => {
                const targetSection = document.getElementById("services");
                targetSection?.scrollIntoView({ behavior: "smooth" });
              }}
            >
              <FaRocket style={{ fontSize: "1.5rem" }} /> Get Started Now
            </button>

            <button
              className={`${styles['hero-button1']} ${styles.button}`}
              type="button"
              onClick={handleDownload}
              style={{
                "--clr": "linear-gradient(135deg,rgb(118, 75, 172), #275fa6)",
              }}
            >
              <FaDownload style={{ fontSize: "1.2rem" }} />
              Download User Guide
            </button>
          </div>
        </section>

        <section className={`${styles['services-section']} py-3 ${styles['bg-light']}`} id="services">
          <h2 className={`${styles['section-heading']} text-center mb-5`}>Our AI Services</h2>

          <div className={`${styles['service-card']} ${styles['main-service-card']} ${styles['mb-5']} ${styles['shadow-lg']} ${styles['border-0']} ${styles['card']}`}>
            <div className={styles['card-body']}>
              <div className={styles['header-section']}>
                <div className={styles['title-badge-wrapper']}>
                  <h3 className={styles['service-title']}>
                    BUSINESS COMMUNICATION ASSISTANCE
                  </h3>
                  <Badge pill className={styles['badge-active']}>
                    Active
                  </Badge>
                </div>
                
                <div className={styles['feedback-contact']}>
                  For feedback and queries please contact{" "}
                  <span
                    className={styles['feedback-email-link']}
                    onClick={() =>
                      (window.location.href = "mailto:bt.ai@analytix.com")
                    }
                  >
                    bt.ai@analytix.com
                  </span>
                </div>
              </div>

              <div className={styles.botRow}>
                {bots.map((bot) => (
                  <div key={bot.id} className={styles.botCol}>
                    <div className={styles['feature-option']}>
                      <div className={styles['feature-icon']}>
                        {bot.icon}
                      </div>
                      <h5 className={styles['feature-title']}>{bot.title}</h5>
                      <p className={`${styles['text-muted']} ${styles['feature-description']} ${styles['mb-3']}`}>
                        {bot.description}
                      </p>
                      <Button
                        variant="primary"
                        onClick={() => handleGetStarted(bot.key)}
                        className={styles['feature-button']}
                      >
                        Get Started
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className={styles['centered-container']}>
            <div className={`${styles['service-card']} ${styles['coming-soon-card']} ${styles['shadow-lg']} ${styles['border-0']}`}>
              <div className={styles['card-body']}>
                <BsChatSquareDots className={styles['coming-soon-card-icon']} />
                <h4 className={styles['coming-soon-title']}>
                  HR policyPal
                  <Badge
                    pill
                    className={`${styles['coming-soon-badge']} ${styles.flash1} ${styles['ms-2']} ${styles['cursor-pointer']}`}
                  >
                    Coming Soon
                  </Badge>
                </h4>
                <p className={`${styles['text-dark']} ${styles['coming-soon-description']}`}>
                  AI-powered virtual assistant that instantly answers HR policy
                  questions, providing accurate guidance from the company's HR
                  policies documentation.
                </p>
              </div>
            </div>
          </div>
        </section>

        <footer className={styles['footer-section']}>
          <div className={styles['footer-icons']}></div>
          <p className={`${styles['mb-0']} ${styles['footer-text']}`}>
            &copy; {new Date().getFullYear()} Analytix Solutions. All Rights
            Reserved.
          </p>
        </footer>

        {error && <ErrorModal error={error} onClose={() => setError(null)} />}
      </div>
    </StyleIsolator>
  );
};

export default LandingPage;