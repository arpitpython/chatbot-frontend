import { BsFileText, BsLightningFill, BsEnvelopeAt } from "react-icons/bs";

const sessionData = [
    {
      session_id: 1,
      title: "Grammar Check",
      description: "Elevate your writing skills with AI-powered grammar Review & Correction",
      icon: <BsLightningFill size={40} />,
      bot_type: "grammar"
    },
    {
      session_id: 2,
      title: "Email Writing",
      description: "Compose & review professional emails with ease and efficiency",
      icon: <BsEnvelopeAt size={40} />,
      bot_type: "email"
    },
    {
      session_id: 3,
      title: "Meeting Insights",
      description: "Effortlessly transform meeting discussions into concise, crystal-clear, and actionable insights & minutes",
      icon: <BsLightningFill size={40} />,
      bot_type: "meeting_insights"
    },
    {
      session_id: 4,
      title: "Document Analysis",
      description: "Powerful AI-driven document analysis tools for extracting insights and making informed decisions.",
      icon: <BsFileText size={40} />,
      bot_type: "document"
    }
  ];

export default sessionData;
