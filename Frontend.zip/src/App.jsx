import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
  useParams,
  useNavigate,
  useLocation,
} from "react-router-dom";
import { v4 as uuidv4 } from 'uuid';
import Navbar from "./components/Navbar/Navbar";
import LeftSidebar from "./components/LeftSidebar/LeftSidebar";
import ChatInterface from "./components/ChatInterface/ChatInterface";
import RightSidebar from "./components/RightSidebar/RightSidebar";
import LandingPage from "./components/LandingPage/LandingPage";
import { 
  fetchDocuments, 
  uploadDocument as apiUploadDocument,
  deleteDocument as apiDeleteDocument,
  sendChatMessage,
  fetchChatSessions,
  fetchChatMessages,
  deleteSession,
  deleteMessage,
  getBaseUrl,
  fetchDocumentMessages,
} from "./utils/api";
import "./App.css";

function App() {
  const storedBotType = sessionStorage.getItem('bot_type');
  
  const getInitialPath = useCallback(() => {
    if (storedBotType) {
      return `/chat/${storedBotType}/new`;
    }
    
    const lastPath = sessionStorage.getItem('lastPath');
    
    if (lastPath && lastPath.startsWith('/chat')) {
      return lastPath;
    }
    
    return '/';
  }, [storedBotType]);

  useEffect(() => {
    const handleBeforeUnload = () => {
      sessionStorage.setItem('lastPath', window.location.pathname);
    };
    
    window.addEventListener('beforeunload', handleBeforeUnload);
    
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, []);

  return (
    <Router>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/chat" element={<Navigate to={getInitialPath()} replace />} />
        <Route path="/chat/document/doc/:documentId" element={<ChatApp botType="document" />} />
        <Route path="/chat/document/new" element={<ChatApp botType="document" newChat={true} />} />
        <Route path="/chat/document/:sessionId" element={<ChatApp botType="document" />} />
        <Route path="/chat/document" element={<ChatApp botType="document" />} />
        <Route path="/chat/:botType/new" element={<ChatApp newChat={true} />} />
        <Route path="/chat/:botType/:sessionId" element={<ChatApp />} />
        <Route path="/chat/:botType" element={<ChatApp />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}

function ChatApp({ newChat = false, botType: propBotType }) {
  const { botType: paramBotType, sessionId, documentId } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const sessionLoadingBlocked = useRef(false);
  
  const validBotTypes = useMemo(() => ['grammar', 'email', 'meeting_insights', 'document'], []);
  const storedBotType = sessionStorage.getItem('bot_type');

  const lastLoadedBotType = useRef(null);
  const lastLoadedDocumentId = useRef(null);
  const lastLoadedSessionId = useRef(null);
  const apiCache = useRef({});
  const isInitialMount = useRef(true);
  const isMounted = useRef(true); // Track component mount state for async operations

  const getBotTypeFromPath = useCallback(() => {
    const path = location.pathname;
    if (path.includes('/chat/document/')) return 'document';
    if (path.includes('/chat/grammar/')) return 'grammar';
    if (path.includes('/chat/email/')) return 'email';
    if (path.includes('/chat/meeting_insights/')) return 'meeting_insights';
    return null;
  }, [location.pathname]);

  const pathBotType = useMemo(() => getBotTypeFromPath(), [getBotTypeFromPath]);
  const initialBotType = useMemo(() => {
    const bot = propBotType || pathBotType || paramBotType || 
      (storedBotType && validBotTypes.includes(storedBotType) ? storedBotType : 'grammar');
    return validBotTypes.includes(bot) ? bot : 'grammar';
  }, [propBotType, pathBotType, paramBotType, storedBotType, validBotTypes]);
  const documentMessagesCache = useRef({});

  const [selectedDocumentId, setSelectedDocumentId] = useState(documentId || null);
  const [selectedBot, setSelectedBot] = useState(initialBotType);
  const [documents, setDocuments] = useState([]);
  const [isLoadingSession, setIsLoadingSession] = useState(false);
  const [forceDocumentsUpdate, setForceDocumentsUpdate] = useState(0);
  const [selectedDocument, setSelectedDocument] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [isDocumentsLoading, setIsDocumentsLoading] = useState(false);
  const [isNewChat, setIsNewChat] = useState(newChat || false);
  const [isMessageSending, setIsMessageSending] = useState(false);
  const [pendingNewSessionId, setPendingNewSessionId] = useState(null);
  const [isNewSessionPending, setIsNewSessionPending] = useState(false);
  const [activeSessionId, setActiveSessionId] = useState(
    isNewChat ? null : (sessionId || null)
  );
  const [chatSessions, setChatSessions] = useState({
    grammar: [],
    email: [],
    meeting_insights: [],
    document: [],
  });

  const [messages, setMessages] = useState([]);
const memoizedMessages = useMemo(() => {
    if (!messages.length) return messages;
    // Create a simple fingerprint of messages array based on length and last message ID
    const lastMessage = messages[messages.length - 1];
    const messagesFingerprint = `${messages.length}-${lastMessage?.id || 'empty'}`;
    return messages;
  }, [messages.length, messages[messages.length - 1]?.id]);

  // Set up component mount tracking
  useEffect(() => {
    isMounted.current = true;
    return () => {
      isMounted.current = false;
    };
  }, []);

  const fetchWithCache = useCallback(async (key, fetchFunction) => {
  if (apiCache.current._pendingRequests && apiCache.current._pendingRequests[key]) {
    console.log(`Reusing in-flight request for ${key}`);
    return apiCache.current._pendingRequests[key];
  }
  
  const cacheEntry = apiCache.current[key];
    if (cacheEntry && Date.now() - cacheEntry.timestamp < 5 * 60 * 1000) {
      console.log(`Using cached result for ${key}`);
      return cacheEntry.data;
    }
    
    if (!apiCache.current._pendingRequests) {
      apiCache.current._pendingRequests = {};
    }
    
    console.log(`Starting new request for ${key}`);
    const requestPromise = fetchFunction().then(result => {
      if (result && result.success) {
        apiCache.current[key] = { data: result, timestamp: Date.now() };
      }

      delete apiCache.current._pendingRequests[key];
      return result;
    }).catch(error => {

      delete apiCache.current._pendingRequests[key];
      throw error;
    });
    
    apiCache.current._pendingRequests[key] = requestPromise;
    return requestPromise;
  }, []);

  useEffect(() => {
    const currentPath = location.pathname;
    sessionStorage.setItem('lastPath', currentPath);
  }, [location.pathname]);

  useEffect(() => {
    const checkSessionTimeout = () => {
      const sessionTimeout = sessionStorage.getItem('session_time_out');
      if (!sessionTimeout) return;
      
      const timeoutMinutes = parseInt(sessionTimeout, 10);
      if (isNaN(timeoutMinutes)) return;
    
      const warningTime = timeoutMinutes - 2;
      const timeoutId = setTimeout(() => {
        if (isMounted.current) {
          setError("Your session will expire soon. Please save your work.");        
        }
      }, warningTime * 60 * 1000);
      
      const expireTimeout = setTimeout(() => {
        if (isMounted.current) {
          sessionStorage.clear();
          navigate('/');
          setError("Session expired. Please log in again.");
        }
      }, timeoutMinutes * 60 * 1000);
      
      return () => {
        clearTimeout(timeoutId);
        clearTimeout(expireTimeout);
      };
    };
    
    const cleanup = checkSessionTimeout();
    return () => {
      if (cleanup) cleanup();
    };
  }, [navigate]);

  const cleanupApiCache = useCallback(() => {
    const now = Date.now();
    const MAX_CACHE_AGE = 10 * 60 * 1000; // 10 minutes
    const MAX_CACHE_ENTRIES = 50;
    
    const cacheEntries = Object.entries(apiCache.current)
      .filter(([key]) => key !== '_pendingRequests')
      .map(([key, value]) => ({ key, timestamp: value.timestamp }))
      .sort((a, b) => b.timestamp - a.timestamp);
    
    // Remove old entries
    cacheEntries.forEach(entry => {
      if (now - entry.timestamp > MAX_CACHE_AGE) {
        delete apiCache.current[entry.key];
      }
    });
    
    // If still too many entries, remove oldest ones
    if (cacheEntries.length > MAX_CACHE_ENTRIES) {
      cacheEntries
        .slice(MAX_CACHE_ENTRIES)
        .forEach(entry => {
          delete apiCache.current[entry.key];
        });
    }
  }, []);

  useEffect(() => {
    const intervalId = setInterval(cleanupApiCache, 5 * 60 * 1000);
    return () => clearInterval(intervalId);
  }, [cleanupApiCache]);

  const loadDocumentMessages = useCallback(async (docId) => {
    if (!docId) {
      console.log(`No document ID provided, skipping message load`);
      return;
    }
    
    if (lastLoadedDocumentId.current === docId && documentMessagesCache.current[docId]?.length > 0) {
      console.log(`Document ${docId} already loaded recently, skipping reload`);
      return;
    }
    
    lastLoadedDocumentId.current = docId;
    
    setIsLoading(true);
    setError(null);
    
    try {
      if (documentMessagesCache.current[docId] && documentMessagesCache.current[docId].length > 0) {
        console.log(`Using cached messages for document ${docId}, found ${documentMessagesCache.current[docId].length} messages`);
        setMessages(documentMessagesCache.current[docId]);
        setIsNewChat(false);
        setIsLoading(false);
        return;
      }
          
      console.log(`No cached messages found, fetching from API for document: ${docId}`);
      const result = await fetchWithCache(`document_messages_${docId}`, 
        () => fetchDocumentMessages(docId)
      );
      
      if (!isMounted.current) return;
      
            let processedMessages = [];
      if (result && result.success && result.messages && result.messages.length > 0) {
        console.log(`Successfully fetched ${result.messages.length} messages from API for document ${docId}`);
        
        processedMessages = result.messages.map((msg, index) => ({
          ...msg,
          id: msg.id || `${Date.now()}_${index}_${msg.sender}`,
          timestamp: msg.timestamp ? new Date(msg.timestamp) : new Date(),
          document_id: docId
        }));
        
        setMessages(processedMessages);
        setIsNewChat(false);
        
        documentMessagesCache.current[docId] = processedMessages;
      } else {
        console.log(`No messages found in API response, checking for document sessions`);
        
        const documentSessions = chatSessions.document.filter(session => 
          session.document_id === docId
        );
        
        if (documentSessions.length > 0) {
          console.log(`Found ${documentSessions.length} sessions for document ${docId}`);
          
          const messagePromises = documentSessions.map(session => 
            fetchChatMessages('document', session.id)
              .then(result => {
                if (result && result.success && result.messages) {
                  return result.messages.map(msg => ({
                    ...msg,
                    document_id: docId
                  }));
                }
                return [];
              })
              .catch(() => [])
          );
          
          const sessionMessages = await Promise.all(messagePromises);
          
          if (!isMounted.current) return;
          
          const allMessages = sessionMessages.flat().sort((a, b) => 
            new Date(a.timestamp) - new Date(b.timestamp)
          );
          
          if (allMessages.length > 0) {
            setMessages(allMessages);
            setIsNewChat(false);
            
            documentMessagesCache.current[docId] = allMessages;
          } else {
            setMessages([]);
            setIsNewChat(true);
            
            documentMessagesCache.current[docId] = [];
          }
        } else {
          setMessages([]);
          setIsNewChat(true);
          
          documentMessagesCache.current[docId] = [];
        }
      }
    } catch (err) {
      if (!isMounted.current) return;
      
      console.error(`Error loading document messages for ${docId}:`, err);
      setError("Failed to load document messages. Please try again later.");
      setMessages([]);
      setIsNewChat(true);
    } finally {
      if (isMounted.current) {
        setIsLoading(false);
      }
    }
  }, [chatSessions.document, fetchWithCache]);

  useEffect(() => {
    if (selectedBot !== storedBotType && storedBotType) {
      sessionStorage.removeItem('bot_type');
    }
  }, [selectedBot, storedBotType]); 

  useEffect(() => {
    if (selectedBot === 'document' && (!selectedDocumentId || documents.length === 0)) {
      setMessages([]);
      setActiveSessionId(null);
      setIsNewChat(true);
    }
  }, [selectedBot, selectedDocumentId, documents]);

  useEffect(() => {
    if (pendingNewSessionId && !isMessageSending) {
      loadChatSessions(selectedBot);
      setPendingNewSessionId(null);
      setIsNewSessionPending(false);
    }
  }, [pendingNewSessionId, isMessageSending, selectedBot]);

  useEffect(() => {
    if (selectedBot && lastLoadedBotType.current !== selectedBot) {
      lastLoadedBotType.current = selectedBot;
      loadChatSessions(selectedBot);
    }
  }, [selectedBot]);

  useEffect(() => {
    const loadDocumentsData = async () => {
      if (isDocumentsLoading || !isMounted.current) return;
      
      setIsDocumentsLoading(true);
      setError(null);
      
      try {
        const result = await fetchWithCache('documents', fetchDocuments);
        
        if (!isMounted.current) return;
        
        if (result.success && result.documents) {
          setDocuments(result.documents);
          
          if (selectedBot === 'document') {
            if (documentId) {
              const docFromUrl = result.documents.find(doc => doc.id === documentId);
              if (docFromUrl) {
                setSelectedDocument(docFromUrl);
                setSelectedDocumentId(documentId);
                loadDocumentMessages(documentId);
                setIsDocumentsLoading(false);
                return;
              }
            }
            
            if (result.documents.length > 0 && !selectedDocument) {
              const firstDoc = result.documents[0];
              setSelectedDocument(firstDoc);
              setSelectedDocumentId(firstDoc.id);
              navigate(`/chat/document/doc/${firstDoc.id}`, { replace: true });
              loadDocumentMessages(firstDoc.id);
            }
          }
        }
      } catch (err) {
        if (isMounted.current) {
          setError("Failed to load documents. Please try again later.");
        }
      } finally {
        if (isMounted.current) {
          setIsDocumentsLoading(false);
        }
      }
    };
    
    if ((selectedBot === 'document') || (documentId && !selectedDocumentId)) {
      loadDocumentsData();
    }
  }, [selectedBot, documentId, navigate, loadDocumentMessages, fetchWithCache]);

  useEffect(() => {
    const loadInitialData = async () => {
      if (isLoading || isDocumentsLoading) return;      
      setIsLoading(true);
      
      try {
        if (selectedBot === 'document' && documents.length === 0) {
          await fetchWithCache('documents', fetchDocuments)
            .then(result => {
              if (result && result.success && result.documents) {
                setDocuments(result.documents);
              }
            })
            .catch(err => console.error('Error fetching documents:', err));
        }
        
        if (lastLoadedBotType.current !== selectedBot) {
          lastLoadedBotType.current = selectedBot;
          await loadChatSessions(selectedBot);
        }
        
        if (activeSessionId && lastLoadedSessionId.current !== activeSessionId) {
          lastLoadedSessionId.current = activeSessionId;
          await loadChatMessages(activeSessionId);
        }
      } catch (err) {
        console.error('Error loading initial data:', err);
        setError("Failed to load data. Please try again later.");
      } finally {
        setIsLoading(false);
      }
    };
    
    loadInitialData();    
  }, [selectedBot, activeSessionId, documents.length, fetchWithCache]);

  useEffect(() => {
    if (documentId && documents.length > 0 && selectedBot === 'document') {
      if (lastLoadedDocumentId.current !== documentId) {
        const docToSelect = documents.find(doc => doc.id === documentId);
        if (docToSelect) {
          console.log(`Loading document ${documentId}`);
          setSelectedDocument(docToSelect);
          setSelectedDocumentId(documentId);
          loadDocumentMessages(documentId);
        } else {
          console.log(`Document ${documentId} not found in loaded documents`);
        }
      }
    }
  }, [documentId, documents, selectedBot, loadDocumentMessages]);

  useEffect(() => {
    if (activeSessionId && lastLoadedSessionId.current !== activeSessionId && !isNewSessionPending) {
      lastLoadedSessionId.current = activeSessionId;
      loadChatMessages(activeSessionId);
    }
  }, [activeSessionId, isNewSessionPending]);
  
  useEffect(() => {
    if (location.pathname.includes('/new')) {
      console.log("URL indicates new chat (/new path detected), resetting chat state");
      
      lastLoadedSessionId.current = null;
      setIsNewChat(true);
      setActiveSessionId(null);
      setMessages([]);
      
      sessionLoadingBlocked.current = true;
      
      const timer = setTimeout(() => {
        sessionLoadingBlocked.current = false;
      }, 300);
      
      return () => clearTimeout(timer);
    }
  }, [location.pathname]);

  useEffect(() => {
    if (selectedBot === 'document' && (documentId || selectedDocument)) {
      return;
    }
    
    if (sessionLoadingBlocked.current) {
      return;
    }
    
    if (sessionId === 'new') {
      setIsNewChat(true);
      setActiveSessionId(null);
      setMessages([]);
      setError(null);
      return;
    }
    
    if (sessionId && lastLoadedSessionId.current !== sessionId) {
      setIsNewChat(false);
      setActiveSessionId(sessionId);
      loadChatMessages(sessionId);
      return;
    }
    
    if (!sessionId && !isNewChat && chatSessions[selectedBot]?.length > 0) {
      const firstSession = chatSessions[selectedBot][0];
      if (firstSession) {
        if (selectedBot === 'document' && documents.length > 0) {
          navigate(`/chat/document/doc/${documents[0].id}`, { replace: true });
        } else {
          const urlSafeSessionId = encodeURIComponent(firstSession.id);
          navigate(`/chat/${selectedBot}/${urlSafeSessionId}`, { replace: true });
        }
      }
    }
  }, [sessionId, chatSessions, selectedBot, documentId, documents, selectedDocument, isNewChat, navigate]);

  const loadChatSessions = useCallback(async (botType) => {
    if (lastLoadedBotType.current === botType && chatSessions[botType]?.length > 0) {
      console.log(`Sessions for ${botType} already loaded, skipping fetch`);
      return;
    }
    
    lastLoadedBotType.current = botType;
    setIsLoading(true);
    setError(null);

    try {
      const result = await fetchWithCache(`sessions_${botType}`, 
        () => fetchChatSessions(botType)
      );
      
      if (!isMounted.current) return;
      
      if (result.success && result.sessions) {
        const sortedSessions = result.sessions.sort((a, b) => 
          new Date(b.last_activity) - new Date(a.last_activity)
        );
        
        setChatSessions(prevSessions => {
          if (prevSessions[botType]?.length === sortedSessions.length &&
              prevSessions[botType][0]?.id === sortedSessions[0]?.id) {
            return prevSessions; 
          }
          return { ...prevSessions, [botType]: sortedSessions };
        });
        
        if (botType === 'document') {
          return;
        }

        if (pendingNewSessionId) {
          const newSession = sortedSessions.find(session => session.id === pendingNewSessionId);
          if (newSession) {
            setActiveSessionId(newSession.id);
            
            if (botType === 'document' && newSession.document_id) {
              navigate(`/chat/document/doc/${newSession.document_id}`, { replace: true });
            } else {
              const urlSafeSessionId = encodeURIComponent(newSession.id);
              navigate(`/chat/${botType}/${urlSafeSessionId}`, { replace: true });
            }
            
            setIsNewChat(false);
            return;
          }
        }
        
        if (!location.pathname.includes('/new') && !isNewChat) {
          if (!activeSessionId && sortedSessions.length > 0) {
            const firstSession = sortedSessions[0];
            setActiveSessionId(firstSession.id);
            
            if (botType === 'document' && firstSession.document_id) {
              navigate(`/chat/document/doc/${firstSession.document_id}`, { replace: true });
            } else {
              const urlSafeSessionId = encodeURIComponent(firstSession.id);
              navigate(`/chat/${botType}/${urlSafeSessionId}`, { replace: true });
            }
            
            loadChatMessages(firstSession.id);
          }
        }
      }
    } catch (err) {
      if (isMounted.current) {
        setError("Failed to load chat history. Please try again later.");
      }
    } finally {
      if (isMounted.current) {
        setIsLoading(false);
      }
    }
  }, [pendingNewSessionId, location.pathname, isNewChat, navigate, activeSessionId, fetchWithCache, chatSessions]);  

  const loadChatMessages = useCallback(async (sessionId) => {
    if (!sessionId || (lastLoadedSessionId.current === sessionId && messages.length > 0)) {
      console.log(`Messages for session ${sessionId} already loaded or no session ID provided, skipping fetch`);
      return;
    }
    
    lastLoadedSessionId.current = sessionId;
    setIsLoadingSession(true);
    setError(null);
    
    try {
      const result = await fetchWithCache(`messages_${selectedBot}_${sessionId}`, 
        () => fetchChatMessages(selectedBot, sessionId)
      );
      
      if (!isMounted.current) return;
      
      if (result && result.success && result.messages && Array.isArray(result.messages)) {
        const processedMessages = result.messages.map((msg, index) => ({
          ...msg,
          id: msg.id || `${Date.now()}_${index}_${msg.sender}`,
          timestamp: msg.timestamp ? new Date(msg.timestamp) : new Date(),
          sessionId: msg.sessionId || sessionId,
          document_id: msg.document_id || null
        }));
        
        if (selectedBot === 'document' && result.document_id) {
          documentMessagesCache.current[result.document_id] = processedMessages;
        }
        
        const hasNewMessages = messages.length !== processedMessages.length ||
                              messages.length === 0 ||
                              messages[messages.length-1]?.id !== processedMessages[processedMessages.length-1]?.id;
                              
        if (hasNewMessages) {
          setMessages(processedMessages);
        }
      } else {
        setMessages([]);
      }
    } catch (err) {
      if (isMounted.current) {
        setError("Failed to load chat messages. Please try again later.");
        setMessages([]);
      }
    } finally {
      if (isMounted.current) {
        setIsLoadingSession(false);
      }
    }
  }, [selectedBot, fetchWithCache, messages]);

  const handleBotChange = useCallback((botType) => {
    if (!validBotTypes.includes(botType) || botType === selectedBot) {
      return;
    }
    
    if (storedBotType) {
      sessionStorage.removeItem('bot_type');
    }
    
    lastLoadedBotType.current = null;
    lastLoadedDocumentId.current = null;
    lastLoadedSessionId.current = null;
    setSelectedBot(botType);
    
    setMessages([]);
    setIsNewChat(true);
    
    if (botType === 'document') {
      if (documents.length > 0) {
        const firstDoc = documents[0];
        setSelectedDocument(firstDoc);
        setSelectedDocumentId(firstDoc.id);
        navigate(`/chat/document/doc/${firstDoc.id}`, { replace: true });
      } else {
        navigate(`/chat/document`, { replace: true });
      }
    } else {
      setSelectedDocument(null);
      setSelectedDocumentId(null);
      
      if (chatSessions[botType]?.length > 0) {
        const firstSession = chatSessions[botType][0];
        const urlSafeSessionId = encodeURIComponent(firstSession.id);
        navigate(`/chat/${botType}/${urlSafeSessionId}`, { replace: true });
      } else {
        navigate(`/chat/${botType}/new`, { replace: true });
      }
    }
  }, [selectedBot, storedBotType, documents, navigate, chatSessions, validBotTypes]);

  const handleBackToLanding = useCallback(() => {
    const login_id = sessionStorage.getItem('user_id');
    const login_key = sessionStorage.getItem('login_key');
    if (login_id && login_key) {
      navigate(`/?user_id=${login_id}&login_key=${login_key}`);
    } else {
      navigate('/');
    }
  }, [navigate]);

  const handleSessionDelete = useCallback(async (sessionId) => {
    try {
      setIsLoading(true);
      const result = await deleteSession(selectedBot, sessionId);
      
      if (!isMounted.current) return;
      
      if (result.success) {
        setChatSessions(prevSessions => {
          const updatedSessions = {
            ...prevSessions,
            [selectedBot]: prevSessions[selectedBot].filter(session => session.id !== sessionId)
          };
          return updatedSessions;
        });
        
        delete apiCache.current[`messages_${selectedBot}_${sessionId}`];
        
        if (sessionId === activeSessionId) {
          setMessages([]);
          setActiveSessionId(null);
          setIsNewChat(true);
          
          if (selectedBot === 'document' && selectedDocumentId) {
              documentMessagesCache.current[selectedDocumentId] = [];
          } else {
              navigate(`/chat/${selectedBot}/new`, { replace: true });
          }
        }
        
        setError(null);
      } else {
        setError("Failed to delete conversation. Please try again.");
      }
    } catch (err) {
      if (isMounted.current) {
        setError("Failed to delete conversation. Please try again later.");
      }
    } finally {
      if (isMounted.current) {
        setIsLoading(false);
      }
    }
  }, [selectedBot, activeSessionId, selectedDocumentId, navigate]);

  const messageDeleteConfig = useMemo(() => ({
    botType: selectedBot,
    docId: selectedDocumentId,
    sessionId: activeSessionId
  }),[selectedBot, selectedDocumentId, activeSessionId]);

  const handleMessageDelete = useCallback(async (messageId) => {
    try {
      setIsLoading(true);      
      const messageToDelete = messages.find(msg => 
        msg.id === messageId || msg.id.startsWith(messageId)
      );
      
      if (!messageToDelete) {
        setError("Message not found. It may have been already deleted.");
        setIsLoading(false);
        return;
      }
      
      const isUserMessage = messageToDelete.sender === 'user';
      let messagesToRemoveIds = [messageToDelete.id];
      
      if (isUserMessage) {
        const messageIndex = messages.findIndex(msg => msg.id === messageToDelete.id);
        if (messageIndex >= 0 && messageIndex < messages.length - 1) {
          const nextMessage = messages[messageIndex + 1];
          if (nextMessage.sender === 'bot') {
            messagesToRemoveIds.push(nextMessage.id);
          }
        }
      }
      
      const result = await deleteMessage(selectedBot, messageToDelete.id);
      if (!isMounted.current) return;
            
      if (result.success) {
        const updatedMessages = messages.filter(msg => !messagesToRemoveIds.includes(msg.id));
        
        if (updatedMessages.length === 0 || (isUserMessage && updatedMessages.length <= 1)) {
          if (activeSessionId) {
            try {
              await deleteSession(selectedBot, activeSessionId);
              delete apiCache.current[`messages_${selectedBot}_${activeSessionId}`];
            } catch (err) {
              console.error("Error deleting empty session:", err);
            }
          }
          
          setMessages([]);
          setActiveSessionId(null);
          setIsNewChat(true);
          
          if (selectedBot === 'document' && selectedDocumentId) {
            documentMessagesCache.current[selectedDocumentId] = [];
            navigate(`/chat/document/doc/${selectedDocumentId}`, { replace: true });
          } else {
            navigate(`/chat/${selectedBot}/new`, { replace: true });
          }
        } else {
          setMessages(updatedMessages);
          
          if (selectedBot === 'document' && selectedDocumentId) {
              if (documentMessagesCache.current[selectedDocumentId]) {
                  documentMessagesCache.current[selectedDocumentId] = updatedMessages;
              }
          }
        }
        
        try {
          await loadChatSessions(selectedBot);
        } catch (sessionErr) {
          console.error("Failed to refresh sessions after message deletion:", sessionErr);
        }
        
        setError(null);
      } else {
        setError("Failed to delete message. Please try again.");
      }
    } catch (err) {
      if (isMounted.current) {
        console.error("Error deleting message:", err);
        setError("Failed to delete message. Please try again later.");
      }
    } finally {
      if (isMounted.current) {
        setIsLoading(false);
      }
    }
  }, [messageDeleteConfig, navigate, loadChatSessions, messages]);

  const handleNewChat = useCallback(() => {
    console.log("handleNewChat called for bot type:", selectedBot);
    
    lastLoadedSessionId.current = null;
    setMessages([]);
    setActiveSessionId(null);
    setIsNewChat(true);
    setPendingNewSessionId(null);
    setIsNewSessionPending(false);
    
    sessionLoadingBlocked.current = true;
    
    delete apiCache.current[`sessions_${selectedBot}`];
    
    if (selectedBot === 'document' && selectedDocumentId) {
      documentMessagesCache.current[selectedDocumentId] = [];
      navigate(`/chat/document/doc/${selectedDocumentId}`, { replace: true });
    } else {
      navigate(`/chat/${selectedBot}/new`, { replace: true });
    }
    
    setTimeout(() => {
      sessionLoadingBlocked.current = false;
    }, 300);
  }, [selectedBot, selectedDocumentId, navigate]);

  const handleSessionSelect = useCallback(async (sessionId) => {
    setPendingNewSessionId(null);
    setIsNewSessionPending(false);
    
    if (sessionId === activeSessionId && messages.length > 0 && lastLoadedSessionId.current === sessionId) {
      return;
    }
    
    setIsNewChat(false);
    setActiveSessionId(sessionId);
    
    if (sessionId !== activeSessionId) {
      setMessages([]);
    }
    
    const session = chatSessions.document.find(s => s.id === sessionId);
    if (selectedBot === 'document' && session && session.document_id) {
      const sessionDocId = session.document_id;
      const sessionDoc = documents.find(d => d.id === sessionDocId);
      
      if (sessionDoc) {
        setSelectedDocument(sessionDoc);
        setSelectedDocumentId(sessionDocId);
        navigate(`/chat/document/doc/${sessionDocId}`, { replace: true });
      }
    }
    
    setIsLoadingSession(true);
    try {
      await loadChatMessages(sessionId);
    } finally {
      if (isMounted.current) {
        setIsLoadingSession(false);
      }
    }
    
    if (selectedBot !== 'document') {
      const urlSafeSessionId = encodeURIComponent(sessionId);
      navigate(`/chat/${selectedBot}/${urlSafeSessionId}`, { replace: true });
    }
  }, [activeSessionId, messages.length, chatSessions.document, selectedBot, documents, navigate, loadChatMessages]);

  const handleDocumentUpload = useCallback(async (newDocument) => {
    setIsDocumentsLoading(true);
    setError(null);
    
    try {
      const result = await apiUploadDocument(newDocument.file, selectedBot);
      
      if (!isMounted.current) return;
      
      if (result.success) {
        const uploadedDocument = {
          id: result.id,
          name: result.name,
          type: result.type,
          size: result.size,
          url: result.url,
          task_type: result.task_type || selectedBot,
          created_at: result.created_at
        };
        
        const updatedDocuments = [uploadedDocument, ...documents];
        setDocuments(updatedDocuments);
        
        setForceDocumentsUpdate(prev => prev + 1);        
        delete apiCache.current['documents'];
        
        setSelectedDocument(uploadedDocument);
        setSelectedDocumentId(uploadedDocument.id);
        
        if (selectedBot === 'document') {
          navigate(`/chat/document/doc/${uploadedDocument.id}`, { replace: true });
        }
        
        setMessages([]);
        setActiveSessionId(null);
        setIsNewChat(true);
        
        documentMessagesCache.current[uploadedDocument.id] = [];
      } else {
        throw new Error(result.message || "Upload failed");
      }
    } catch (err) {
      if (isMounted.current) {
        setError(`Failed to upload document: ${err.message}`);
      }
    } finally {
      if (isMounted.current) {
        setIsDocumentsLoading(false);
      }
    }
  }, [selectedBot, documents, navigate]);

  
  const handleDocumentSelect = useCallback((document) => {
    if (document.id === selectedDocumentId) {
      return;
    }
    
    setSelectedDocumentId(document.id);
    setSelectedDocument(document);
    
    navigate(`/chat/document/doc/${document.id}`, { replace: true });
  }, [selectedDocumentId, navigate]);

  const handleDocumentDelete = useCallback(async (documentId) => {
    console.log(`Deleting document: ${documentId}`);
    
    if (isDocumentsLoading) {
      return;
    }
    
    setIsDocumentsLoading(true);
    setError(null);
    
    try {
      const updatedDocuments = documents.filter(doc => doc.id !== documentId);
      setDocuments(updatedDocuments);      
      setForceDocumentsUpdate(prev => prev + 1);
      
      delete documentMessagesCache.current[documentId];
      delete apiCache.current[`document_messages_${documentId}`];
      delete apiCache.current['documents'];
      
      await apiDeleteDocument(documentId);
      
      if (!isMounted.current) return;
      
      let sessionsToDelete = [];
      for (const session of chatSessions.document) {
        if (session.document_id === documentId) {
          sessionsToDelete.push(session.id);
          try {
            await deleteSession('document', session.id);
            delete apiCache.current[`messages_document_${session.id}`];
          } catch (err) {
            console.error(`Error deleting session ${session.id}:`, err);
          }
        }
      }
      
      await loadChatSessions('document');
      
      if (selectedDocumentId === documentId) {
        setMessages([]);
        setActiveSessionId(null);
        
        if (updatedDocuments.length > 0) {
          const nextDoc = updatedDocuments[0];
          
          setSelectedDocument(nextDoc);
          setSelectedDocumentId(nextDoc.id);          
          navigate(`/chat/document/doc/${nextDoc.id}`, { replace: true });
          
        } else {
          setSelectedDocument(null);
          setSelectedDocumentId(null);
          setIsNewChat(true);
          navigate(`/chat/document`, { replace: true });
        }
      }
    } catch (err) {
      if (isMounted.current) {
        console.error(`Error in handleDocumentDelete:`, err);
        setError(`Failed to delete document: ${err.message}`);
        
        fetchWithCache('documents', fetchDocuments)
          .then(result => {
            if (result && result.success && result.documents) {
              setDocuments(result.documents);
            }
          })
          .catch(e => console.error("Error reloading documents after delete failure:", e));
      }
    } finally {
      if (isMounted.current) {
        setIsDocumentsLoading(false);
      }
    }
  }, [isDocumentsLoading, documents, chatSessions.document, selectedDocumentId, navigate, loadChatSessions, fetchWithCache]);

  const handleSendMessage = useCallback(async (content, file = null) => {
    if (isMessageSending) {
      console.log("Message send already in progress, ignoring request");
      return;
    }

    const userId = sessionStorage.getItem('user_id');
    const loginKey = sessionStorage.getItem('login_key');
    const loginEmail = sessionStorage.getItem('email');
    
    if (!userId || !loginKey) {
      setError("Authentication required. Please refresh the page and login again.");
      return;
    }

    setIsMessageSending(true);
    
    let currentSessionId = activeSessionId;
    let isNewSession = false;
    
    try {
      if (!currentSessionId) {
        currentSessionId = `${uuidv4()}`;
        
        if (!isNewSessionPending) {
          setPendingNewSessionId(currentSessionId);
          setIsNewSessionPending(true);
          isNewSession = true;
        }

        setChatSessions(prevSessions => ({
          ...prevSessions,
          [selectedBot]: [{
            id: currentSessionId,
            title: content.length > 20 ? content.substring(0, 20) + '...' : content || "New Chat",
            preview: content || "New conversation",
            created_at: new Date().toISOString(),
            last_activity: new Date().toISOString(),
            document_id: selectedBot === 'document' && selectedDocument ? selectedDocument.id : null
          }, ...prevSessions[selectedBot]]
        }));
        
        setActiveSessionId(currentSessionId);
        lastLoadedSessionId.current = currentSessionId;
        setIsNewChat(false);
        
        if (selectedBot !== 'document') {
          const urlSafeSessionId = encodeURIComponent(currentSessionId);
          navigate(`/chat/${selectedBot}/${urlSafeSessionId}`, { replace: true });
        }
      }
    
      let messageContent = content;
      if (file) {
        const fileInfo = `[File: ${file.name}]`;
        messageContent = content ? `${content}\n${fileInfo}` : fileInfo;
      }

      const newUserMessage = {
        id: Date.now() + '_user',
        content: messageContent,
        sender: "user",
        timestamp: new Date(),
        sessionId: currentSessionId,
        document_id: selectedBot === 'document' && selectedDocument ? selectedDocument.id : null
      };

      const tempBotMessage = {
        id: Date.now() + '_bot_loading',
        content: "...",
        sender: "bot",
        isLoading: true,
        timestamp: new Date(),
        sessionId: currentSessionId,
        document_id: selectedBot === 'document' && selectedDocument ? selectedDocument.id : null
      };

      setMessages(prevMessages => [...prevMessages, newUserMessage, tempBotMessage]);
      
      if (selectedBot === 'document' && selectedDocument && selectedDocument.id) {
        documentMessagesCache.current[selectedDocument.id] = [
          ...(documentMessagesCache.current[selectedDocument.id] || []),
          newUserMessage,
          tempBotMessage
        ];
      }

      let documentId = null;      
      if (selectedBot === 'document' && selectedDocument) {
        documentId = selectedDocument.id;
      } else if (file) {
        try {
          const uploadResult = await apiUploadDocument(file, selectedBot);
          
          if (!isMounted.current) return;
          
          if (uploadResult.success) {
            documentId = uploadResult.id;
            
            if (selectedBot === 'document') {
              const uploadedDocument = {
                id: uploadResult.id,
                name: uploadResult.name,
                type: uploadResult.type,
                size: uploadResult.size,
                url: uploadResult.url,
                task_type: uploadResult.task_type || selectedBot, 
                created_at: uploadResult.created_at
              };
              
              setSelectedDocument(uploadedDocument);
              setSelectedDocumentId(uploadedDocument.id);
              
              navigate(`/chat/document/doc/${uploadedDocument.id}`, { replace: true });
              
              documentMessagesCache.current[uploadResult.id] = [newUserMessage, tempBotMessage];
            }
          } else {
            throw new Error(uploadResult.message || "File upload failed");
          }
        } catch (err) {
          throw new Error(`Failed to upload file: ${err.message}`);
        }
      }
      
      const response = await sendChatMessage(
        content, 
        selectedBot, 
        documentId,
        currentSessionId,
        userId,
        loginKey,
        loginEmail
      );
      
      if (!isMounted.current) return;
      
      const botResponse = {
        id: Date.now() + '_bot',
        content: response.message || response.bot_response,
        sender: 'bot',
        timestamp: new Date(),
        sessionId: currentSessionId,
        document_id: selectedBot === 'document' && selectedDocument ? selectedDocument.id : null
      };
      
      setMessages(prevMessages => {
        const filteredMessages = prevMessages.filter(msg => msg.id !== tempBotMessage.id);
        const userMessages = filteredMessages.filter(msg => msg.id === newUserMessage.id);
        if (userMessages.length === 0) {
          return [...filteredMessages, newUserMessage, botResponse];
        }
        return [...filteredMessages, botResponse];
      });
      
      if (selectedBot === 'document' && selectedDocument) {
        const currentMessages = documentMessagesCache.current[selectedDocument.id] || [];
        const filteredMessages = currentMessages.filter(msg => msg.id !== tempBotMessage.id);
        const userMessages = filteredMessages.filter(msg => msg.id === newUserMessage.id);
        if (userMessages.length === 0) {
          documentMessagesCache.current[selectedDocument.id] = [...filteredMessages, newUserMessage, botResponse];
        } else {
          documentMessagesCache.current[selectedDocument.id] = [...filteredMessages, botResponse];
        }
      }
      
      delete apiCache.current[`sessions_${selectedBot}`];
      await loadChatSessions(selectedBot);

      if (isNewSession) {
        await loadChatMessages(currentSessionId);
      }
    } catch (err) {
      if (!isMounted.current) return;
      
      setError(`Failed to get response: ${err.message}`);
      
      const errorMessage = {
        id: Date.now() + '_error',
        content: `Sorry, I couldn't process your request. Please try again.`,
        sender: "bot",
        timestamp: new Date(),
        sessionId: currentSessionId,
        document_id: selectedBot === 'document' && selectedDocument ? selectedDocument.id : null
      };
      
      setMessages(prevMessages => {
        return [...prevMessages.filter(msg => !msg.isLoading), errorMessage];
      });
      
      if (selectedBot === 'document' && selectedDocument) {
        const currentMessages = documentMessagesCache.current[selectedDocument.id] || [];
        documentMessagesCache.current[selectedDocument.id] = [
          ...currentMessages.filter(msg => !msg.isLoading),
          errorMessage
        ];
      }
      
      await loadChatSessions(selectedBot);
    } finally {
      if (isMounted.current) {
        setIsMessageSending(false);
        setIsNewSessionPending(false);
      }
    }
  }, [isMessageSending, activeSessionId, selectedBot, selectedDocument, navigate, 
      loadChatSessions, loadChatMessages, isNewSessionPending]);

  const processedMessages = useMemo(() => {
    if (!messages.length) return messages;
    return messages.map(msg => ({
      ...msg,
      id: msg.id || `${Date.now()}_${msg.sender}`,
      timestamp: msg.timestamp ? new Date(msg.timestamp) : new Date(),
    }));
  }, [messages]);

  const memoizedChatInterface = useMemo(() => (
    <ChatInterface
      messages={processedMessages}
      onSendMessage={handleSendMessage}
      selectedBot={selectedBot}
      selectedDocument={selectedDocument}
      onMessageDelete={handleMessageDelete}
      isMessageSending={isMessageSending}
      isLoadingSession={isLoadingSession}
      activeSessionId={activeSessionId}
    />
  ), [
    processedMessages, 
    handleSendMessage, 
    selectedBot, 
    selectedDocument, 
    handleMessageDelete, 
    isMessageSending, 
    isLoadingSession, 
    activeSessionId
  ]);

  const memoizedLeftSidebar = useMemo(() => (
    <LeftSidebar
      selectedBot={selectedBot}
      onBotChange={handleBotChange}
      documents={documents}
      documentsKey={`${forceDocumentsUpdate}-${documents.length}-${documents[0]?.id || 'empty'}`}
      onDocumentSelect={handleDocumentSelect}
      onDocumentUpload={handleDocumentUpload}
      onDocumentDelete={handleDocumentDelete}
      chatSessions={chatSessions}
      selectedDocumentId={selectedDocumentId}
      isDocumentsLoading={isDocumentsLoading}
      activeSessionId={activeSessionId}
      onSessionSelect={handleSessionSelect}
      onNewChat={handleNewChat}
      onSessionDelete={handleSessionDelete}
      isNewChat={isNewChat}
      pendingNewSessionId={pendingNewSessionId}
    />
  ), [
    selectedBot,
    handleBotChange,
    documents,
    forceDocumentsUpdate, 
    handleDocumentSelect,
    handleDocumentUpload,
    handleDocumentDelete,
    chatSessions, 
    selectedDocumentId,
    isDocumentsLoading,
    activeSessionId,
    handleSessionSelect,
    handleNewChat,
    handleSessionDelete,
    isNewChat,
    pendingNewSessionId
  ]);

  // const memoizedRightSidebar = useMemo(() => 
  //   selectedBot === "document" ? (
  //     <RightSidebar selectedDocument={selectedDocument} />
  //   ) : null
  // , [selectedBot, selectedDocument]);

  return (
    <div className="app">
      <Navbar onBackToLanding={handleBackToLanding} />
      
      {error && (
        <div className="error-banner">
          {error}
          <button onClick={() => setError(null)}>Dismiss</button>
        </div>
      )}
      
      {isLoading && (
        <div className="loading-indicator"></div>
      )}
      
      <div className="main-container">
        {memoizedLeftSidebar}
        {memoizedChatInterface}
        {/* {memoizedRightSidebar} */}
      </div>
    </div>
  );
}

export default App;  
