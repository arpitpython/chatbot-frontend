import { apiGet } from './csrfUtils';
import { getBaseUrl, MAIN_ENDPOINT } from '../components/endpoints.js';
import { debounce } from 'lodash';

const API_BASE_URL = getBaseUrl();
const pendingRequests = {};

const requestRateLimiter = {
  requestTimestamps: {},
  minInterval: 300,
  
  shouldBlock(key) {
    const now = Date.now();
    const lastRequest = this.requestTimestamps[key] || 0;
    
    if (now - lastRequest < this.minInterval) {
      return true;
    }
    
    this.requestTimestamps[key] = now;
    return false;
  }
};

// Helper function to implement rate limiting
const withRateLimit = async (key, requestFunction) => {
  if (requestRateLimiter.shouldBlock(key)) {
    console.log(`Rate limited: ${key} - Request too frequent`);
    return Promise.reject(new Error("Request rate limited. Please try again in a moment."));
  }
  
  return requestFunction();
};

export const fetchDocuments = async () => {
  const requestKey = 'documents';
  if (pendingRequests[requestKey]) {
    console.log("Reusing pending fetchDocuments request");
    return pendingRequests[requestKey];
  }
  
  console.log("fetchDocuments: Starting new request");
  
  const requestPromise = withRateLimit(requestKey, async () => {
    try {
      const response = await apiGet(`${API_BASE_URL}/api/get_documents/`);
      
      if (!response.ok) {
        const errorClone = response.clone();
        const errorText = await errorClone.text();
        console.error("fetchDocuments: Error response", errorText);
        throw new Error(`Failed to fetch documents: ${response.status} - ${errorText}`);
      }
      
      const data = await response.json();
      console.log("fetchDocuments: Successfully fetched", data.documents?.length || 0, "documents");
      return data;
    } catch (error) {
      console.error('Error fetching documents:', error);
      throw error;
    } finally {
      delete pendingRequests[requestKey];
    }
  });
  
  pendingRequests[requestKey] = requestPromise;
  return requestPromise;
};

export const fetchDocumentsDebounced = debounce(fetchDocuments, 300);

export const uploadDocument = async (file, botType = 'document') => {
  const requestKey = `upload_document_${file.name}`;
  
  return withRateLimit(requestKey, async () => {
    console.log("uploadDocument: Starting upload", { fileName: file.name, botType });
    try {
      const loginEmail = sessionStorage.getItem('email');
      const formData = new FormData();
      formData.append('file', file);
      formData.append('task_type', botType); 
      formData.append('user_email', loginEmail); 
      
      console.log("uploadDocument: Sending request");
      const response = await fetch(`${API_BASE_URL}/api/upload_document/`, {
        method: 'POST',
        body: formData
      });
      
      console.log("uploadDocument: Response status", response.status);
      if (!response.ok) {
        const responseClone = response.clone();
        let errorText = '';
        try {
          errorText = await responseClone.text();
          console.log("uploadDocument: Error response", errorText);
        } catch (e) {
          console.log("uploadDocument: Failed to read error response", e);
        }
        const responseData = await response.json();
        const errorMessage =
          responseData?.error || `Upload failed with status ${response.status}`;
        throw new Error(errorMessage);
      }
      
      const data = await response.json();
      console.log("uploadDocument: Successfully uploaded", data);
      return data;
    } catch (error) {
      console.error('Error uploading document:', error);
      throw error;
    }
  });
};

export const deleteDocument = async (documentId) => {
  const requestKey = `delete_document_${documentId}`;
  
  return withRateLimit(requestKey, async () => {
    console.log("deleteDocument: Starting deletion", { documentId });
    try {
      console.log("deleteDocument: Sending request");
      const response = await fetch(`${API_BASE_URL}/api/delete_document/${documentId}/`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json'
        }
      });
      
      console.log("deleteDocument: Response status", response.status);
      if (!response.ok) {
        const responseClone = response.clone();
        let errorMessage = `Failed to delete document: ${response.status}`;
        try {
          const errorText = await responseClone.text();
          errorMessage += ` - ${errorText}`;
          console.log("deleteDocument: Error response", errorText);
        } catch (textError) {
          console.warn('Could not read error response body', textError);
        }
        throw new Error(errorMessage);
      }
      
      console.log("deleteDocument: Successfully deleted document");
      return true;
    } catch (error) {
      console.error('Error deleting document:', error);
      throw error;
    }
  });
};

export const fetchChatSessions = async (botType) => {
  const requestKey = `fetch_chat_sessions_${botType}`;
  
  return withRateLimit(requestKey, async () => {
    console.log("fetchChatSessions: Starting request", { botType });
    try {
      const loginEmail = sessionStorage.getItem('email');
      console.log("fetchChatSessions: Using email", loginEmail);
      
      console.log("fetchChatSessions: Sending request");
      const response = await fetch(`${API_BASE_URL}/api/chat_sessions/?bot_type=${botType}&user_email=${loginEmail}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json'
        }
      });
      
      console.log("fetchChatSessions: Response status", response.status);
      if (!response.ok) {
        const errorClone = response.clone();
        const errorText = await errorClone.text();
        console.log("fetchChatSessions: Error response", errorText);
        throw new Error(`Failed to fetch chat sessions: ${response.status} - ${errorText}`);
      }
      
      const data = await response.json();
      console.log("fetchChatSessions: Successfully fetched", data.sessions?.length || 0, "sessions");
      
      if (botType === 'document' && data.success && data.sessions) {
        data.sessions = data.sessions.map(session => {
          if (session.metadata && session.metadata.document_id) {
            return {
              ...session,
              document_id: session.metadata.document_id
            };
          }
          
          if (session.title && session.title.includes('Document:')) {
            const match = session.title.match(/Document: ([a-zA-Z0-9-]+)/);
            if (match && match[1]) {
              return {
                ...session,
                document_id: match[1]
              };
            }
          }
          
          return session;
        });
      }
      
      return data;
    } catch (error) {
      console.error('Error fetching chat sessions:', error);
      throw error;
    }
  });
};

export const fetchChatSessionsDebounced = debounce(fetchChatSessions, 300);

export const fetchChatMessages = async (botType, sessionId) => {
  const requestKey = `fetch_chat_messages_${botType}_${sessionId}`;
  
  return withRateLimit(requestKey, async () => {
    console.log("fetchChatMessages: Starting request", { botType, sessionId });
    try {
      if (!sessionId) {
        console.error("No sessionId provided to fetchChatMessages");
        throw new Error("Session ID is required");
      }
      
      if (!botType) {
        console.error("No botType provided to fetchChatMessages");
        throw new Error("Bot type is required");
      }
      
      const encodedSessionId = encodeURIComponent(sessionId);
      
      const timestamp = Date.now();
      const url = `${API_BASE_URL}/api/chat_messages/${botType}/${encodedSessionId}/?_t=${timestamp}`;
      
      console.log("fetchChatMessages: Sending request to", url);
      const response = await fetch(url, {
        method: 'GET',
        cache: 'no-store',
        headers: {
          'Content-Type': 'application/json'
        }
      });
      
      console.log("fetchChatMessages: Response status", response.status);
      if (!response.ok) {
        const errorClone = response.clone();
        let errorText;
        try {
          errorText = await errorClone.text();
          console.log("fetchChatMessages: Error response", errorText);
        } catch (e) {
          console.log("fetchChatMessages: Failed to read error response", e);
          errorText = `Error status: ${response.status}`;
        }
        throw new Error(`Failed to fetch chat messages: ${response.status} - ${errorText}`);
      }
      
      const data = await response.json();
      console.log("fetchChatMessages: Successfully fetched", data.messages?.length || 0, "messages");
      
      if (data.document_id) {
        if (data.messages && Array.isArray(data.messages)) {
          data.messages = data.messages.map(msg => ({
            ...msg,
            document_id: data.document_id
          }));
        }
      }
      
      return data;
    } catch (error) {
      console.error('Error fetching chat messages:', error);
      throw error;
    }
  });
};

export const fetchChatMessagesDebounced = debounce(fetchChatMessages, 300);

export const sendChatMessage = async (message, botType, documentId=null, sessionId=null, userId, loginKey, loginEmail) => {
  const requestKey = `send_chat_message_${botType}_${sessionId || 'new'}`;
  
  return withRateLimit(requestKey, async () => {
    console.log("sendChatMessage: Starting request", { 
      messageLength: message?.length || 0,
      botType, 
      documentId, 
      sessionId,
      userId,
      loginEmail 
    });
    
    try {
      const requestBody = {
        message,
        botType,
        sessionId,
        userId, loginKey, loginEmail
      };
      
      if (documentId) {
        requestBody.documentId = documentId;
      }
      
      console.log("sendChatMessage: Sending request with body", requestBody);
      
      const start = performance.now();
      const response = await fetch(`${API_BASE_URL}/api/process_message/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody)
      });
      
      const end = performance.now();
      console.log(`Process took ${(end - start) / 1000} milliseconds`);
      console.log("sendChatMessage: Response status", response.status);
      
      if (!response.ok) {
        const errorData = await response.json();
        console.log("sendChatMessage: Error response", errorData);
        if (errorData.error && errorData.error.summary) {
          throw new Error(errorData.error.summary);
        } else if (errorData.message) {
          throw new Error(errorData.message);
        } else if (errorData.error) {
          throw new Error(errorData.error);
        } else {
          throw new Error(`Request failed with status ${response.status}`);
        }
      }
      
      const responseData = await response.json();
      console.log("sendChatMessage: Successfully sent message, response", responseData);
      
      if (botType === 'document' && documentId && responseData.session_id) {
        try {
          const sessionTitle = responseData.session_title || "Untitled Conversation";
          const newTitle = sessionTitle.includes(`Document: ${documentId}`) 
            ? sessionTitle 
            : `Document: ${documentId} - ${sessionTitle}`;
          
          console.log("sendChatMessage: Updating session with document info", {
            sessionId: responseData.session_id || sessionId,
            newTitle
          });
          
          await fetch(`${API_BASE_URL}/api/update_session/`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              session_id: responseData.session_id || sessionId,
              bot_type: botType,
              title: newTitle,
              metadata: {
                document_id: documentId
              }
            })
          });
        } catch (err) {
          console.error('Error updating session with document info:', err);
        }
      }
      
      return responseData;
    } catch (error) {
      console.error('Error getting bot response:', error);
      throw error;
    }
  });
};

export const deleteSession = async (botType, sessionId) => {
  const requestKey = `delete_session_${botType}_${sessionId}`;
  
  return withRateLimit(requestKey, async () => {
    console.log("deleteSession: Starting deletion", { botType, sessionId });
    try {
      const encodedSessionId = encodeURIComponent(sessionId);
      
      console.log("deleteSession: Sending request");
      const response = await fetch(`${API_BASE_URL}/api/delete_session/${botType}/${encodedSessionId}/`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
        }
      });
      
      console.log("deleteSession: Response status", response.status);
      if (!response.ok) {
        const errorClone = response.clone();
        let errorText;
        try {
          errorText = await errorClone.text();
          console.log("deleteSession: Error response", errorText);
        } catch (e) {
          console.log("deleteSession: Failed to read error response", e);
          errorText = `Error status: ${response.status}`;
        }
        throw new Error(`Failed to delete session: ${response.status} - ${errorText}`);
      }
      
      const data = await response.json();
      console.log("deleteSession: Successfully deleted session", data);
      return data;
    } catch (error) {
      console.error('Error deleting session:', error);
      throw error;
    }
  });
};

export const deleteMessage = async (botType, messageId) => {
  const requestKey = `delete_message_${botType}_${messageId}`;
  
  return withRateLimit(requestKey, async () => {
    console.log("deleteMessage: Starting deletion", { botType, messageId });
    try {
      console.log("deleteMessage: Sending request");
      const response = await fetch(`${API_BASE_URL}/api/delete_message/${botType}/${messageId}/`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
        }
      });
      
      console.log("deleteMessage: Response status", response.status);
      if (!response.ok) {
        const errorClone = response.clone();
        let errorText;
        try {
          errorText = await errorClone.text();
          console.log("deleteMessage: Error response", errorText);
        } catch (e) {
          console.log("deleteMessage: Failed to read error response", e);
          errorText = `Error status: ${response.status}`;
        }
        throw new Error(`Failed to delete message: ${response.status} - ${errorText}`);
      }
      
      const data = await response.json();
      console.log("deleteMessage: Successfully deleted message", data);
      return data;
    } catch (error) {
      console.error('Error deleting message:', error);
      throw error;
    }
  });
};

export const fetchDocumentMessages = async (documentId) => {
  const requestKey = `fetch_document_messages_${documentId}`;
  
  return withRateLimit(requestKey, async () => {
    console.log("fetchDocumentMessages: Starting request", { documentId });
    try {
      if (!documentId) {
        throw new Error("Document ID is required");
      }
      
      const encodedDocumentId = encodeURIComponent(documentId);
      
      const timestamp = Date.now();
      const url = `${API_BASE_URL}/api/document_messages/${encodedDocumentId}/?_t=${timestamp}`;
      
      console.log("fetchDocumentMessages: Sending request to", url);
      const response = await fetch(url, {
        method: 'GET',
        cache: 'no-store',
        headers: {
          'Content-Type': 'application/json'
        }
      });
      
      console.log("fetchDocumentMessages: Response status", response.status);
      if (!response.ok) {
        const errorClone = response.clone();
        let errorText;
        try {
          errorText = await errorClone.text();
          console.log("fetchDocumentMessages: Error response", errorText);
        } catch (e) {
          console.log("fetchDocumentMessages: Failed to read error response", e);
          errorText = `Error status: ${response.status}`;
        }
        throw new Error(`Failed to fetch document messages: ${response.status} - ${errorText}`);
      }
      
      const data = await response.json();
      console.log("fetchDocumentMessages: Successfully fetched", data.messages?.length || 0, "messages");
      
      if (!data || !data.messages) {
        return { success: true, messages: [], document_id: documentId };
      }
      
      if (data.messages && Array.isArray(data.messages)) {
        data.messages = data.messages.map(msg => ({
          ...msg,
          document_id: documentId
        }));
      }
      
      return data;
    } catch (error) {
      console.error('Error fetching document messages:', error);
      throw error;
    }
  });
};

export const fetchDocumentMessagesDebounced = debounce(fetchDocumentMessages, 300);

export const downloadUserGuide = async () => {
  const requestKey = 'download_user_guide';
  
  return withRateLimit(requestKey, async () => {
    console.log("downloadUserGuide: Starting download");
    try {
      console.log("downloadUserGuide: Sending request");
      const response = await fetch(`${MAIN_ENDPOINT}/api/download-user-guide`);
      console.log("downloadUserGuide: Response status", response.status);
      
      if (!response.ok) {
        let errorMsg = `Network response was not ok. Status: ${response.status}`;
        try {
          const errorData = await response.json();
          if (errorData.error) {
            errorMsg += ` - ${errorData.error}`;
          }
          console.log("downloadUserGuide: Error response", errorData);
        } catch (jsonError) {
          console.log("downloadUserGuide: Failed to read error response", jsonError);
        }
        throw new Error(errorMsg);
      }
      
      const data = await response.json();
      console.log("downloadUserGuide: Successfully downloaded guide", { fileName: data.file_name });
      const { file_name, file_type, file_data } = data;

      const byteCharacters = atob(file_data);
      const byteNumbers = new Array(byteCharacters.length)
        .fill(0)
        .map((_, i) => byteCharacters.charCodeAt(i));
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: file_type });

      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = file_name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Downloading File Error:", error);
      throw new Error("Downloading File Error: " + error.message);
    }
  });
};

export const getCsrfTokenUrl = () => `${API_BASE_URL}/api/csrf-token/`;
export { getBaseUrl };
