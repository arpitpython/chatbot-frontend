export const getCsrfTokenFromCookie = () => {
  return null;
};

export const fetchCsrfToken = async (baseUrl) => {
  console.log("CSRF token fetching disabled");
  return "";
};

export const getCsrfToken = () => {
  return "";
};

export const apiRequest = async (url, options = {}) => {
  try {
    const baseUrl = url.split('/api/')[0]; 
    const loginEmail = sessionStorage.getItem('email');

    if (!loginEmail) {
      console.warn('Authentication credentials missing from session storage');
    }

    const method = options.method || 'GET';
    const headers = {
      'Accept': 'application/json',
      ...(options.headers || {}),
    };

    if (options.body instanceof FormData) {
      delete headers['Content-Type'];
    } else if (
      options.body && 
      typeof options.body === 'object' && 
      !headers['Content-Type'] &&
      !(options.body instanceof FormData)
    ) {
      headers['Content-Type'] = 'application/json';
    }

    const requestOptions = {
      ...options,
      method,
      // credentials: 'include', 
      mode: 'cors',
      headers,
    };

    // Get user_id and login_key from sessionStorage
    const userId = sessionStorage.getItem('user_id');
    const loginKey = sessionStorage.getItem('login_key');

    // For GET requests, add auth params to the URL
    if (method === 'GET' && loginEmail) {
      const separator = url.includes('?') ? '&' : '?';
      url = `${url}${separator}user_email=${loginEmail}`;
    }

    if ((method === 'POST' || method === 'PUT') && loginEmail) {
      if (requestOptions.body instanceof FormData) {
        requestOptions.body.append('user_email', loginEmail);
                
        if (userId && loginKey) {
          requestOptions.body.append('user_id', userId);
          requestOptions.body.append('login_key', loginKey);
        }
      } else if (typeof requestOptions.body === 'object' && !(requestOptions.body instanceof FormData)) {
        let bodyObj = requestOptions.body;        
        if (typeof bodyObj === 'string') {
          try {
            bodyObj = JSON.parse(bodyObj);
          } catch (e) {
            console.warn('Could not parse request body as JSON:', e);
            bodyObj = {};
          }
        }
        
        bodyObj = {
          ...bodyObj,
          user_email: loginEmail
        };
        
        if (userId && loginKey) {
          bodyObj.user_id = userId;
          bodyObj.login_key = loginKey;
        }
        
        requestOptions.body = bodyObj;
      }
    }

    if (
      requestOptions.body && 
      typeof requestOptions.body === 'object' && 
      !(requestOptions.body instanceof FormData) &&
      !requestOptions.body.toString().includes('[object FormData]')
    ) {
      try {
        if (typeof requestOptions.body !== 'string') {
          requestOptions.body = JSON.stringify(requestOptions.body);
        }
      } catch (e) {
        console.warn('Could not stringify request body:', e);
      }
    }

    console.log(`${method} request to ${url} without CSRF token`);
    const response = await fetch(url, requestOptions);
    const responseClone = response.clone();
    
    if (!response.ok) {
      try {
        const errorText = await responseClone.text();
        console.error(`Server returned error status: ${response.status}`, errorText);
      } catch (e) {
        console.error(`Server returned error status: ${response.status}`, "Could not read response body");
      }
    }
    
    return response;
  } catch (error) {
    console.error('API Request Error:', error);
    throw error;
  }
};

export const apiGet = (url) => apiRequest(url, { method: 'GET' });
export const apiPost = (url, data) => apiRequest(url, { method: 'POST', body: data });
export const apiPut = (url, data) => apiRequest(url, { method: 'PUT', body: data });
export const apiDelete = (url) => apiRequest(url, { method: 'DELETE' });